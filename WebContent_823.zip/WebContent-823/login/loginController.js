angular.module('owb').controller('loginController', loginController);

loginController.$inject = ['$rootScope'];
function loginController($rootScope){
	$rootScope.login=true;
	$rootScope.showChat=true;
	$('.nav-tabs a').click(function (e) {
	    e.preventDefault();
	    $(this).tab('show');
	});
	$('.nexttab').click(function(){
		  $('.nav-tabs > .active').next('li').find('a').trigger('click');
	});
	
	$('.newsticker').newsTicker({
		max_rows: 5
	});
	
	
}