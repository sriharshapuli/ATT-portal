angular
		.module('owb')
		.directive(
				'loadingctl',
				function() {
					return {
						restrict : 'E',
						replace : true,
						template : '<div class="loading"><img src="/styles/css/images/loader.gif" width="20" height="20" />LOADING...</div>',
						link : function(scope, element) {
							scope.$watch('loadingctl', function(val) {
								if (val) {
									$(element).show();
								} else {
									$(element).hide();
								}
							});
						}
					};
				});