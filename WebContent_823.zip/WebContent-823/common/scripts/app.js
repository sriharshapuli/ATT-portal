/* Create the module OWB and initialize the OWB application */
var owb = angular.module('owb', [ 'ngRoute']);
/* configure OWB routes */
angular.module('owb').config(config);


function config($routeProvider) {
	$routeProvider

	// route for Menu page
	.when('/login', {
		templateUrl : 'login/login.html',
		controller : 'loginController'
	}).when('/signup', {
		templateUrl : 'signup/signup.html',
		controller : 'loginController'
	}).when('/home', {
		templateUrl : 'common/views/menu.html',
		controller:'menuController',
		controllerAs:'menuController'
	}).when('/security', {
		templateUrl : 'signup/security.html',
		controller: 'securityController'
	}).when('/securityInternal', {
		templateUrl : 'security/securityInternal.html',
		controller: 'securityController'
	}).when('/securityExternal', {
		templateUrl : 'security/securityExternal.html',
		controller: 'securityController'
	}).when('/address', {
		templateUrl : 'address/address.html',
		controller: 'securityController'
	}).when('/changeAddress', {
		templateUrl : 'address/changeAddress.html',
		controller: 'securityController'
	}).when('/changeOwnership', {
		templateUrl : 'address/changeOwnership.html',
		controller: 'securityController'
	}).when('/help', {
		templateUrl : 'common/views/help.html'
	}).when('/admin',{
		templateUrl : 'admin/admin.html'
	}).when('/adminWork',{
		templateUrl : 'admin/workQueue.html'
	}).when('/adminTicket',{
		templateUrl : 'admin/ticketDetails.html'
	}).when('/payment',{
		templateUrl : 'payment/payment.html'
	}).when('/paymentDetails',{
		templateUrl : 'payment/paymentDetails.html'
	}).when('/vendorSearch',{
		templateUrl : 'payment/vendorSearch.html'
	}).when('/agreement',{
		templateUrl : 'Agreements/agreement.html'
	}).when('/formTemplate',{
		templateUrl : 'templates/template.html'
	})
	.when('/createUserExternalConfirmation',{
		templateUrl : 'user/createUserExternalConfirmation.html'
	}).when('/forgot',{
		templateUrl : 'forgot/forgot.html'
	}).when('/forgotConfirmation',{
		templateUrl : 'forgot/forgotConfirmation.html'
	})
	.when('/createUser', {
		templateUrl : 'user/createUser.html',
		controller : 'createUser'
	
	}).when('/userExternal', {
		templateUrl : 'user/createUserExternal.html',
		controller : 'createUser'
	}).when('/userInternal', {
		templateUrl : 'user/createUserInternal.html',
		controller : 'createUser'
	}).when('/manageuserprofile', {
		templateUrl : 'manage/manageuserprofile.html',
		controller:'createUser'
	}).when('/usersearch', {
		templateUrl : 'manage/usersearch.html',
		controller:'createUser'
	})
	.otherwise({
		redirectTo : '/login'
	});

}

