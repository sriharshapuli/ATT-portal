angular.module('owb').controller('headerController', headerController);

headerController.$inject = ['$rootScope'];
function headerController($rootScope){
	var vm=this;
	vm.openNav=openNav;
	function openNav() {
		document.getElementById('pedowbSidenav').style.width = '250px';
		document.getElementById('owbMenu').style.marginLeft = '250px';
	}
	vm.closeNav=closeNav;
	function closeNav() {
		document.getElementById('pedowbSidenav').style.width = '0';
		document.getElementById('owbMenu').style.marginLeft = '0';
	}
	if (document.getElementById('owbMenu') != null) {

		document.getElementById('owbMenu').addEventListener('click', closeNav);
		$('#owbMenu').click(function() {
			if ($('#owbsearch').hasClass('in')) {
				$('#owbsearch').removeClass('collapse in');
			}
		});

	}
	$('.dropdown-menu').find('input').click(function(e) {
		e.stopPropagation();
	});
}
