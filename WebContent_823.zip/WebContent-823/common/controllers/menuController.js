angular.module('owb').controller('menuController', menuController);

menuController.$inject = ['$rootScope'];
function menuController($rootScope){
	$rootScope.login=false;
	var vm=this;
	vm.chatBoxToggle=chatBoxToggle;
	function chatBoxToggle(){
		console.log("Inside chatbox toggle");
		$('.chat_window').toggle();
	}
}