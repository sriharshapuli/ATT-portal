angular.module('owb').controller('securityController', securityController);

securityController.$inject = [];
function securityController(){
	
	$('.nav-tabs a').click(function (e) {
	    e.preventDefault();
	    $(this).tab('show');
	});
}