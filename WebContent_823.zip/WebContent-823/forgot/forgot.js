angular.module('owb').controller('forgot', forgot);

forgot.$inject = ['$rootScope'];
function forgot($rootScope){
	//alert('1');
	$rootScope.login=true;
	$rootScope.showChat=true;
	$('.nav-tabs a').click(function (e) {
	    e.preventDefault();
	    $(this).tab('show');
	});
	$('.nexttab').click(function(){
		  $('.nav-tabs > .active').next('li').find('a').trigger('click');
	});
	
	$('.newsticker').newsTicker({
		max_rows: 5
	});
	
	
}