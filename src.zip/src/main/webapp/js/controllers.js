var app=angular.module('pedespgui');

app.controller('MainCtrl',
function MainCtrl($scope, $http, $rootScope, $cookieStore, GlobalLogonSvc,DropDownSvc,$location,MessageSvc,RoleSvc) {
	
	console.log("MainCtrl init");
	
    userRoleTimer();
    function userRoleTimer(){
         
                   setTimeout(function(){
	var actionList = $cookieStore.get("roles");

                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
 $scope.$apply(function () {
	 
	 if(actionList.indexOf("CFGUPD") !== -1)
	 {
	 $rootScope.updateEspShow = true; 
	 $rootScope.isSuperAdmin = true;
	 console.log("user is a Super Admin");	
	 }	 
	 else if(actionList.indexOf("ADDESP") !== -1)
	{
	$rootScope.updateEspShow = true; 
	console.log("user is an Admin");	
	}
else
	{
	console.log("no admin/super admin roles found");	
	console.log(window.location.hash)
	if(window.location.hash==="#/home"){
		
	}else{
	$location.path('/home/');
	
	//console.log("no role present in AddUpdateCtrl");	
	}
	}

           });
               		  
                      }

  },800);
     }
	//flag to show menu as per role.
	$rootScope.updateEspShow = false; // admin flag
	$rootScope.isSuperAdmin= false; //superadmin flag 
	$rootScope.selectedAPI = {};
	$rootScope.selectedApplication = {};
	$rootScope.selectedOption = null;
	$rootScope.actionList = [];
 
if($cookieStore.get("userName")!='User')	{ 
	  setTimeout(function() { 
          $scope.$apply(function() { 
  			$rootScope.attuid = $cookieStore.get("attuid"); 
  			//console.log("$rootScope.userName"+$rootScope.userName); 
  			 $rootScope.whenOnhome=true;
          }); 
        }, 2000); 
} 
else{ 
	$rootScope.userName =  $cookieStore.get("userName"); 
	//console.log("In else cookieStore value  "+$cookieStore.get("userName")) 
}

	$rootScope.flashMsg= $cookieStore.get("flashMsg");
	$rootScope.$on('NewInfoMessage', function(event,dataMsg){
			 $('#info-msg').modal('show');
		 
	  });
	 $rootScope.whenOnhome=true;
	
 
	  //function called on ok button of modal with id="info-msg" ,to redirect to searchesp page. 	
$rootScope.redirectsearchESP=function(){
	$('#info-msg').modal('hide');
	//window.location.reload();
	}



$rootScope.$on('BusyStart', function(){
    // 	angular.element('#busy-spinner').modal('show');
       $("#busy-spinner").css("display", "block"); 
  });

$rootScope.$on('BusyEnd', function(){
$("#busy-spinner").css("display", "none"); 
//   	angular.element('#busy-spinner').modal('hide');

  });

$("#error-msg").find("#okError").on("click",function(){
	  window.location.reload();
});


}
);

//Controller for AddUpdate page where an excel download and upload is provided
app.controller('AddUpdateCtrl',
function AddUpdateCtrl($scope, $http, $log, $rootScope,$location, $cookieStore,ConfigSvc, MessageSvc,GlobalLogonSvc,DropDownSvc,uploadSvc) {

    userRoleTimer();
    function userRoleTimer(){
         
                   setTimeout(function(){
	var actionList = $cookieStore.get("roles");

                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
 $scope.$apply(function () {
	 if(actionList.indexOf("CFGUPD") !== -1)
	 {
	 $rootScope.updateEspShow = true; 
	 $rootScope.isSuperAdmin = true;
	 console.log("user is a Super Admin");	
	 }	 
	 else if(actionList.indexOf("ADDESP") !== -1)
	{
	$rootScope.updateEspShow = true; 
	console.log("user is a an Admin");	
	}
else
	{
	$location.path('/home/');
	console.log("no admin/super admin roles found");	
	}
DropDownSvc.dropDownValues("USH");

           });
               		  
                      }

  },800);
     }
    

    $rootScope.$on('dropDownDataObject', function (events,args) { 	
    $rootScope.ushLinkValue = DropDownSvc.dropDownData[0].values;
    console.log("ushlink "+$rootScope.ushLinkValue);
    });
    
    $scope.uploadTextShow = false; //flag to show the full data on click here to see more
    
    $scope.uploadTextShowFunc = function () {
    	
	  	$scope.uploadTextShow = true;
	}
    
    $scope.uploadTextHideFunc = function () {
    	
	  	$scope.uploadTextShow = false;
	}
    
	$rootScope.whenOnhome=false;
	console.log("Addupdate controller");
	$scope.addUpdateRole = null;


	        	    	$scope.LoadRefFileFlagEmpty = false; // for showing only .xml files are allowed

	//function to remove required error on selection of file after the error message
	$scope.fileSelect = function ()
	{
	    $("input:file").change(function () {
	        $scope.LoadRefFileFlag = false;
	        $("#fileErrorMsg").css("display", "none"); // hide the error msg id
	    });

	};
	

	$scope.LoadRefFileFlag = false;//file select mandate

	$scope.LoadRefDdFunc = function (fileChoose)
	{

	    //check if the file is selected for upload
	    $scope.selectedFile = fileChoose;
	    var filebrowse = "#" + fileChoose;
	    var filename= document.getElementById("fileLoadBrowse").files;
	    var fileHandle = $(filebrowse)[0].files[0];
	    console.log("filename1: "+fileHandle);
	    var filePath = $(filebrowse).val();

	    var fileName = filePath.split(/(\\|\/)/g).pop(); //Gets the file name from the  path
	
	    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
	    console.log("file extension: " + ext);

	    
	
	    if ($(filebrowse)[0].files[0] === undefined || $(filebrowse)[0].files[0] === null) 
	    {
	        $scope.LoadRefFileFlag = true;
	       // MessageSvc.displayErrorMessage("Empty file, please upload with valid content");
	       // $rootScope.$broadcast('reloadOnErrorMsg');
	        console.log("Please Select a file.");
	        return;
	    }
	    else
	    {   
	    	  $scope.LoadRefFileFlag = false;
	    	  if(filename[0].size==0)
	          {
	          	$scope.LoadRefFileFlagZero=true;
		        console.log("The file is empty, please check and upload a valid file again.");
	          }
	          else
	          {
	          	    $scope.LoadRefFileFlagZero=false;	

	        	    if ((ext == 'xml' || ext == 'XML' ) && !$scope.LoadRefFileFlag)
	        	    {
	        	    	$scope.LoadRefFileFlagEmpty = false;
	        	    	uploadSvc.addUploadEsp(fileHandle);
	        	    }
	        	    else
	        	    { 
	        	    	$scope.LoadRefFileFlagEmpty = true;
	        	    	    //MessageSvc.displayErrorMessage ("Please select only XML file to upload");
	    	        }
	          }
	          $scope.LoadRefFileFlag = false;
	    }
	}
	

	$scope.downloadForTemp = function () { 
	   	$('#iframeview').html('<iframe src="images/ESP_TEMPLATE.xlsx"></iframe>'); 
		}
	
	$scope.downloadForAID = function () { 
	   	$('#iframeviewAID').html('<iframe src="images/ESP_JobAID.xlsx"></iframe>'); 
		}
	
	
	
	 $rootScope.$on('NewErrorMessage', function(event,dataMsg){
     	$('#error-msg').modal('show');
     });
	 
	 $rootScope.$on('NewInfoMessage', function(event,dataMsg){
	     	$('#info-msg').modal('show');
	     });
	 
	 $rootScope.redirectsearchESP=function(){
			$('#info-msg').modal('hide');
			//window.location.reload();
			}
	 
	 $rootScope.$on('BusyStart', function(){
		       $("#busy-spinner").css("display", "block"); 
		  });

		$rootScope.$on('BusyEnd', function(){
		$("#busy-spinner").css("display", "none"); 
		  });

		$("#error-msg").find("#okError").on("click",function(){
			  window.location.reload();
		});

}
);



app.controller('searchLocationCtrl',
		function searchLocationCtrl($scope ,$log ,$location, $rootScope,$cookieStore, MessageSvc,DropDownSvc,$http,GlobalLogonSvc){
	
console.log("inside searchLocationCtrl");
userRoleTimer();
function userRoleTimer(){
     
               setTimeout(function(){
                var actionList = $cookieStore.get("roles"); 
                
                  if(actionList === undefined)
                  {
                     	   userRoleTimer();
                  }
                  else{
$scope.$apply(function () {
 
	if(actionList.indexOf("CFGUPD") !== -1)
	 {
	 $rootScope.updateEspShow = true; 
	 $rootScope.isSuperAdmin = true;
	 console.log("user is a Super Admin");	
	 }
	else if(actionList.indexOf("SRCHESPEDT") !== -1)
		{
		 $rootScope.updateEspShow = true; 
		console.log("user is a an Admin");	
		}
	else
		{
		console.log("no admin/super admin roles found");	
		}
	console.log("inside DropDownSvc CNTRY_CD");
	$rootScope.whenOnhome = false; // to hide bldg image from the footer
	DropDownSvc.dropDownValues("CNTRY_CD");
	
    
       });
           		  
                  }

},800);
 }

$scope.MowSearch = {};
$scope.addresstypeFlag = false; //error flag for address type
$scope.submitMowFlag = false;//submit flag

$rootScope.$on('dropDownDataObject', function (events,args) {
	mowCountryDD=[];
	countForCountry = 0;
$rootScope.valuesData = DropDownSvc.dropDownData;
	for(var i in $rootScope.valuesData){
		
	if($rootScope.valuesData[i].key == "CNTRY_CD"){
		
		var criteria=[];
		if($rootScope.valuesData!=null){
			criteria=$rootScope.valuesData[i].values.split(':');
		}		
		mowCountryDD[i] = criteria[0];
		/*
		mowCountryDD[countForCountry]=$rootScope.valuesData[i].values;
			countForCountry = countForCountry + 1;*/
		}
	}
	
	$scope.MowCountryoptions = mowCountryDD;

});

$scope.MowSearchreset = function()
{
	$scope.MowSearch = {};
	$scope.addresstypeFlag = false; 
	$scope.submitMowFlag = false;//submit flag
}

//function to perform seach for the location search page
$scope.searchMow = function()
{
	$scope.submitMowFlag = true;//submit flag
	$scope.checkAddressMandate();
	if(!$scope.addresstypeFlag)
		{
		MessageSvc.displayInfoMessage('No matching data found, please try again.');
		}
}

$scope.checkAddressMandate = function()
{
	if($scope.submitMowFlag && $scope.MowSearch.Address !== undefined)
	{
	console.log("Address fields has value, check for address type");/*
	console.log("$scope.MowSearch.SupplierAdd"+$scope.MowSearch.SupplierAdd);
	console.log("$scope.MowSearch.EspAdd"+$scope.MowSearch.EspAdd);
	console.log("$scope.MowSearch.GeoCodeAdd"+$scope.MowSearch.GeoCodeAdd);*/
	 if(
			 ($scope.MowSearch.SupplierAdd === undefined || $scope.MowSearch.SupplierAdd == false) &&
			 ($scope.MowSearch.EspAdd === undefined || $scope.MowSearch.EspAdd == false) &&
			 ($scope.MowSearch.GeoCodeAdd === undefined || $scope.MowSearch.GeoCodeAdd == false) )
		 {
		 console.log("neither of the checkbox is selected");
		  $scope.addresstypeFlag = true;
		 }
	 else
		 {
		 console.log("either of the checkbox is selected");
		 $scope.addresstypeFlag = false;
		 }
	}
	else
		{
		 $scope.addresstypeFlag = false;
		}
}

$rootScope.$on('NewInfoMessage', function(event,dataMsg){
	 $('#info-msg').modal('show');

});

$("#info-msg").find("#okBtn").on("click", function () {
	$('#info-msg').modal('hide');
});	

});

app.controller('AllSearchCtrl',
function AllSearchCtrl($scope ,$log ,$location, $rootScope,$cookieStore, MessageSvc,DropDownSvc,AllEspSearchSvc,myService,$http,GlobalLogonSvc){
	
    userRoleTimer();
    function userRoleTimer(){
         
                   setTimeout(function(){
                    var actionList = $cookieStore.get("roles"); 
                    
                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
 $scope.$apply(function () {
	 
	 if(actionList.indexOf("CFGUPD") !== -1)
	 {
	 $rootScope.updateEspShow = true; 
	 $rootScope.isSuperAdmin = true;
	 console.log("user is a Super Admin");	
	 }
	 else if(actionList.indexOf("SRCHESPEDT") !== -1)
			{
		 $rootScope.updateEspShow = true; 
			console.log("user is a an Admin with role SRCHESPEDT ");	
			}
		else
			{
			
			console.log("no admin/super admin roles found, user has role: SRCHESPVW ");	
			}
		if(bck == null || bck == undefined){
		DropDownSvc.dropDownValues("ESP_SEARCH_TYPE");
		}
        
           });
               		  
                      }

  },800);
     }
	//DropDownSvc.dropDownValues("ESP_SEARCH_TYPE");
	$scope.selectedOption = {};
	$rootScope.selectedOption = {};
	//$rootScope.searchByCountryInput = {}; 
	$scope.searchByProductInput={};
	//$scope.firstProdType = "Product Type";
	//$scope.searchByProductInput.Product_Type = [];
	$scope.prod_type = [];
	$scope.prod_type_val = [];
	  $scope.addNewChoice = function() {
		  if($scope.searchByProductInput.firstProdType !== null || $scope.searchByProductInput.firstProdType !== '' || $scope.searchByProductInput.firstProdType !== undefined)
		  {
			  if(Object.keys($scope.prod_type).length < 1)
			  {
				  var newItemNo = Object.keys($scope.prod_type).length+1;
				  $scope.prod_type.push(newItemNo);
			  }
		  }
		  else
			  {
			  	$scope.searchByProductFlags.ProductTypeFlag = true;
			  }
		  };

	$scope.removeChoice = function() 
	{
		var lastItem = $scope.prod_type.length-1;
		//$scope.searchByProductInput.prod_type.splice(lastItem);
		$scope.prod_type.splice(lastItem);
		$scope.prod_type_val.splice(lastItem);
	};
	var espSearchDD = [];
	//var espSearchDDVal = [];
	var countForIntConctTyp = 1;
	var countForCountry = 1;
	var countForNetwork = 0;
	var countForProduct = 0;
	var countForattProductStatus = 0;
	var espCountryCodeDD = [];
	var NwespCountryCodeDD = [];
	var espInterconnectTypeDD = [];
	var espProductCountryCodesDD = [];
	var attProductStatusDD = [];
	
$scope.selectChange1 = function () {
	$scope.submitFlag = false;
	$scope.countryMandate = false;
	$scope.networkITUMandate = false;
	$scope.networkCountryMandate = false;
	$scope.searchByCountryInput = {}; 
	$scope.searchByProdDetail = {}; 
	$scope.searchByNetworkInput = {};
	$scope.searchByProductInput={};
	espInterconnectTypeDD = [];
	attProductStatusDD = [];
	countForIntConctTyp = 1;
	countForCountry = 1;
	countForattProductStatus = 0;
	countForNetwork = 0;
	countForProduct = 0;
	//$rootScope.selectedOption.value = $scope.selectedOption.value;
	var back1 = $rootScope.backValue;
	if(back1!=null && back1!=undefined){
		$scope.selectedOption.value = back1;
	}
	if($scope.selectedOption.value == "Country"){
		DropDownSvc.dropDownValues("CNTRY_CD");
	}
	else if($scope.selectedOption.value == "Network"){
		DropDownSvc.dropDownValues("ESP_NW_SEARCH");
	}
	else if($scope.selectedOption.value == "Product"){
		DropDownSvc.dropDownValues("ESP_PRODUCT_SEARCH");
	}
}
	//$scope.selectChange1();
	$rootScope.$on('dropDownDataObject', function (events,args) {
	
	$rootScope.valuesData = DropDownSvc.dropDownData;
	$rootScope.espSearchDDKey=[];
	$rootScope.espSearchDDVal=[];
	$rootScope.espSearchfromAppKey=[];
	$rootScope.espSearchfromAppVal=[];
	
		for(var i in $rootScope.valuesData){
			
			if($rootScope.valuesData[i].key == "SCH_API_NM"){
				var criteria=[];
				if($rootScope.valuesData[i].values!=null){
					criteria=$rootScope.valuesData[i].values.split(':');
				}
				
				espSearchDD[i] = criteria[0];
				$rootScope.espSearchDDKey[i]=criteria[0];
				$rootScope.espSearchDDVal[i] = criteria[1];
			}

			else if($rootScope.valuesData[i].key == "CNTRY_CD" && $scope.selectedOption.value == "Country"){
				var criteria=[];
				if($rootScope.valuesData!=null){
					criteria=$rootScope.valuesData[i].values.split(':');
				}
				
				espCountryCodeDD[i] = criteria[0];
				
				$rootScope.espSearchfromAppKey[i]=criteria[0];
				$rootScope.espSearchfromAppVal[i]=criteria[1];
			}
			else if($rootScope.valuesData[i].key == "CNTRY_CD" && $scope.selectedOption.value == "Network"){
				var criteria=[];
				if($rootScope.valuesData!=null){
					criteria=$rootScope.valuesData[i].values.split(':');
				}
				
				NwespCountryCodeDD[i] = criteria[0];
				
				$rootScope.espSearchfromAppKey[i]=criteria[0];
				$rootScope.espSearchfromAppVal[i]=criteria[1];

			}
			
			else if($rootScope.valuesData[i].key == "NWCNCT_TYP"){
				espInterconnectTypeDD[countForIntConctTyp]=$rootScope.valuesData[i].values;
				countForIntConctTyp=countForIntConctTyp+1;
			}
			
			else if($rootScope.valuesData[i].key == "PDCNTRY_CD"){
				espProductCountryCodesDD[countForProduct]=$rootScope.valuesData[i].values;
				countForProduct = countForProduct+1;
			}
			
			else if($rootScope.valuesData[i].key == "ATT_PRD_ST"){
				attProductStatusDD[countForattProductStatus]=$rootScope.valuesData[i].values;
				countForattProductStatus=countForattProductStatus+1;
			}
			
		}
		
		espInterconnectTypeDD[0] = "--SELECT--";
		espCountryCodeDD[0] = "--SELECT--";
		
		$scope.optionType = espSearchDD;
		$scope.options = espCountryCodeDD;
		$scope.options1 = NwespCountryCodeDD;
		$scope.option = espInterconnectTypeDD;
		$scope.cntry = espProductCountryCodesDD;
		$scope.attStatus = attProductStatusDD;
		$rootScope.optionType = $scope.optionType;
		$rootScope.options = $scope.options;
		$rootScope.options1 = $scope.options1;
		$rootScope.option = $scope.option ;
		$rootScope.cntry = $scope.cntry;
		$rootScope.attStatus = $scope.attStatus;
		
	
	});
                    
	$rootScope.$on('NewInfoMessage', function(event,dataMsg){
		 $('#info-msg').modal('show');
	 
 });
	$rootScope.whenOnhome=false;
	$rootScope.redirectsearchESP=function(){
		$('#info-msg').modal('hide');
		//window.location.reload();
		}
	
	$scope.searchByCountryInput = {};
	$scope.searchByNetworkInput = {};
	$scope.searchByProdDetail = {}; 
	$scope.searchByProductInput={};
	
	var back = $rootScope.backValue;
	
	bck = $rootScope.backValue;
	
	if(back != null){
		$scope.selectedOption.value = back;
		
		$scope.optionType = $rootScope.optionType;
		$scope.options = $rootScope.options;
		$scope.options1 = $rootScope.options1;
		$scope.option = $rootScope.option;
		$scope.cntry = $rootScope.cntry;
		$scope.attStatus = $rootScope.attStatus;
		
		$scope.searchByCountryInput = $rootScope.allDataCountry;
		$scope.searchByNetworkInput = $rootScope.allDataNetwork;
		$scope.searchByProductInput = $rootScope.allDataProduct ;
		$scope.searchByProdDetail = $rootScope.allDataProductDetails ;
	}
	else{
		$scope.selectedOption.value = null;
	}
	$rootScope.backValue = null;
	
	
	
	//$scope.selectedOption= null;
	$scope.dataToShare = [];
	
	//$scope.searchByCountryFlag = false;
	$scope.submitFlag = false // flag on submit buttons
	
	//initilizing error message flags
	$scope.searchByProdDetail.mandateFlag = false;
	$scope.searchByProductFlags={}; 
	$scope.selectoneFlag = false //error message flag to display atleast one of teh items
	$scope.countryMandate = false; // mandate flag for country
	$scope.networkITUMandate = false; // mandate flag for network itu code
	$scope.networkCountryMandate = false; //mandate flag for network country code
	 
	
$rootScope.$on('BusyStart', function(){
	     // 	angular.element('#busy-spinner').modal('show');
	        $("#busy-spinner").css("display", "block"); 
       });
$rootScope.$on('BusyEnd', function(){
	$("#busy-spinner").css("display", "none"); 
    //   	angular.element('#busy-spinner').modal('hide');

       });

    // fnumber function to check number validations on input fields
	$scope.fnumber = function()
	{
		$scope.speedFlag = false;
		$scope.CMTUFlag = false;
		$scope.latFlag = false;
		$scope.longFlag = false;
		
		//if is not a number and field is not empty
		if(isNaN($scope.searchByProductInput.Cust_Speed) && (($scope.searchByProductInput.Cust_Speed !== null) || ($scope.searchByProductInput.Cust_Speed !== '') || ($scope.searchByProductInput.Cust_Speed !== undefined))){
					$scope.speedFlag = true;
				}
		if(isNaN($scope.searchByProductInput.CMTU) && (($scope.searchByProductInput.CMTU !== null) || ($scope.searchByProductInput.CMTU !== '') || ($scope.searchByProductInput.CMTU !== undefined)))	
				{
					$scope.CMTUflag = true;
				}
		if(isNaN($scope.searchByProductInput.Lat) && (($scope.searchByProductInput.Lat !== null) || ($scope.searchByProductInput.Lat !== '') || ($scope.searchByProductInput.Lat !== undefined)))
				{
					$scope.latFlag = true;
				}
		if(isNaN($scope.searchByProductInput.Long) && (($scope.searchByProductInput.Long !== null) || ($scope.searchByProductInput.Long !== '') || ($scope.searchByProductInput.Long !== undefined)))
				{
					$scope.longFlag = true;
				}
		//if is a number but field is empty
		if(!isNaN($scope.searchByProductInput.Cust_Speed) || ($scope.searchByProductInput.Cust_Speed === null) || ($scope.searchByProductInput.Cust_Speed === '') || ($scope.searchByProductInput.Cust_Speed === undefined)){
				$scope.speedFlag = false;
				
			}
		if(!isNaN($scope.searchByProductInput.CMTU)  || ($scope.searchByProductInput.CMTU === null) || ($scope.searchByProductInput.CMTU === '') || ($scope.searchByProductInput.CMTU === undefined))	
			{
				$scope.CMTUflag = false;
			}
		if(!isNaN($scope.searchByProductInput.Lat) || ($scope.searchByProductInput.Lat === null) || ($scope.searchByProductInput.Lat === '') || ($scope.searchByProductInput.Lat === undefined))
			{
				$scope.latFlag = false;
			}
		if(!isNaN($scope.searchByProductInput.Long) || ($scope.searchByProductInput.Long === null) || ($scope.searchByProductInput.Long === '') || ($scope.searchByProductInput.Long === undefined))
			{
				$scope.longFlag = false;
			}

	}
	//end fnumber function
	
	$scope.selectChange = function () {

		$scope.countryMandate = false;
		$scope.searchByProductFlags.latitudeFlag = false;
		$scope.searchByProductFlags.longitudeFlag = false;
		$scope.searchByProductFlags.CustomerSpeedFlag = false;
		$scope.searchByProductFlags.ATTProductStatusFlag = false;
		$scope.searchByProductFlags.ProdTypeFlag = false;
		$scope.searchByProductFlags.CountryFlag = false;
		
	}
	
	$scope.mandateforCountry = function () {

		if($scope.submitFlag === true)
			{
		
		  if(($scope.searchByCountryInput.COUNTRY === null || $scope.searchByCountryInput.COUNTRY === '' || $scope.searchByCountryInput.COUNTRY === undefined || $scope.searchByCountryInput.COUNTRY === "--SELECT--")
				  &&
				  ($scope.searchByCountryInput.ITUPCODE === null || $scope.searchByCountryInput.ITUPCODE === '' || $scope.searchByCountryInput.ITUPCODE === undefined)
				  )
			  {
			    $scope.countryMandate = true;
			  }
		  else
			  {
			  $scope.countryMandate = false;
			  }
			}
	}
	
	$scope.mandateforNetwork = function () {
		
		//mandatory checks for network
		if($scope.submitFlag === true)
			{
			if(($scope.searchByNetworkInput.COUNTRY === null || $scope.searchByNetworkInput.COUNTRY === '' || $scope.searchByNetworkInput.COUNTRY === undefined) || ($scope.searchByNetworkInput.ItuCode === null || $scope.searchByNetworkInput.ItuCode === '' || $scope.searchByNetworkInput.ItuCode === undefined))
			{
				if($scope.searchByNetworkInput.COUNTRY === null || $scope.searchByNetworkInput.COUNTRY === '' || $scope.searchByNetworkInput.COUNTRY === undefined)
				  {
				    $scope.networkCountryMandate = true;
				  }
				if(($scope.searchByNetworkInput.ItuCode === null || $scope.searchByNetworkInput.ItuCode === '' || $scope.searchByNetworkInput.ItuCode === undefined))
			  	{
			  		$scope.networkITUMandate = true;
			  	}
			}
		  else
			  {
			  $scope.networkCountryMandate = false;
			  $scope.networkITUMandate = false;
			  }
			}
	}
	
	$scope.mandateforProductDetail = function () {

		if($scope.submitFlag === true)
			{
			 if($scope.searchByProdDetail.ATTProductID === null || $scope.searchByProdDetail.ATTProductID === '' || $scope.searchByProdDetail.ATTProductID === undefined){
				  $scope.searchByProdDetail.mandateFlag= true;
			  }
			  else
			  {
				  $scope.searchByProdDetail.mandateFlag= false;
			  }
			}
	}
	
	$scope.mandateForProduct = function()
	{
		if($scope.submitFlag === true)
			{
			if($scope.searchByProductInput.Country_Code === null || $scope.searchByProductInput.Country_Code === '' || $scope.searchByProductInput.Country_Code === undefined){
				  $scope.searchByProductFlags.CountryFlag= true;
			  }
			  if($scope.searchByProductInput.Cust_Speed === null || $scope.searchByProductInput.Cust_Speed === '' || $scope.searchByProductInput.Cust_Speed === undefined){
				  $scope.searchByProductFlags.CustomerSpeedFlag= true;
			  }
			  if($scope.searchByProductInput.firstProdType === null || $scope.searchByProductInput.firstProdType === '' || $scope.searchByProductInput.firstProdType === undefined){
				  $scope.searchByProductFlags.ProdTypeFlag= true;
			  }
			  if($scope.searchByProductInput.ATT_Product_Status === null || $scope.searchByProductInput.ATT_Product_Status === '' || $scope.searchByProductInput.ATT_Product_Status === undefined){
				  $scope.searchByProductFlags.ATTProductStatusFlag= true;
			  }
			  else
				  {
					if(!($scope.searchByProductInput.Country_Code === null || $scope.searchByProductInput.Country_Code === '' || $scope.searchByProductInput.Country_Code === undefined)){
						 $scope.searchByProductFlags.CountryFlag= false;
					  }
					  if(!($scope.searchByProductInput.Cust_Speed === null || $scope.searchByProductInput.Cust_Speed === '' || $scope.searchByProductInput.Cust_Speed === undefined)){
						  $scope.searchByProductFlags.CustomerSpeedFlag= false;
					  }
					  if(!($scope.searchByProductInput.firstProdType === null || $scope.searchByProductInput.firstProdType === '' || $scope.searchByProductInput.firstProdType === undefined)){
						  $scope.searchByProductFlags.ProdTypeFlag= false;
					  }
					  if(!($scope.searchByProductInput.ATT_Product_Status === null || $scope.searchByProductInput.ATT_Product_Status === '' || $scope.searchByProductInput.ATT_Product_Status === undefined)){
						  $scope.searchByProductFlags.ATTProductStatusFlag= false;
					  }
				  }
			}
	}

	  $scope.focusToInvalidField=function(){
    	  var field = null,
    	  firstError = null;
    	  for (field in $scope.networkSearch) {
    		  if (field[0] != '$')
    		  {
    			  if (firstError === null && $scope.networkSearch[field].$invalid) {
    				  firstError = $scope.networkSearch[field].$name;
    				  
    			  }

    			  if ($scope.networkSearch[field].$pristine) {
    				  $scope.networkSearch[field].$dirty = true;
    			  }
    		  }
    	  }
    	  $("#"+firstError).focus();
      };
	
  $scope.AllEspSearch = function()
  {
	  $scope.submitFlag = true;
	  
	  $rootScope.selectedOption.value = $scope.selectedOption.value; // to display on the search result page
	  
	  $rootScope.allDataCountry = $scope.searchByCountryInput;
	  $rootScope.allDataNetwork = $scope.searchByNetworkInput;
	  $rootScope.allDataProduct = $scope.searchByProductInput;
	  $rootScope.allDataProductDetails = $scope.searchByProdDetail;
	  
	  
	  if($scope.selectedOption.value === "Product Details")
	  {
		  $scope.mandateforProductDetail();
		  if($scope.searchByProdDetail.mandateFlag === false){
		  if($scope.searchByProdDetail.ATTProductID === null || $scope.searchByProdDetail.ATTProductID === '' || $scope.searchByProdDetail.ATTProductID === undefined){
		  $scope.searchByProdDetail.ATTProductID= '';
		  }
		/*  AllEspSearchSvc.searchByProductDetail($scope.searchByProdDetail.ATTProductID);*/
		  AllEspSearchSvc.searchBySearchCriteria("ProductDetails",$scope.searchByProdDetail.ATTProductID,
				  null,null,null,null,null,null,null,null,null,null,null);
		  }
		  }
	  else if ($scope.selectedOption.value === "Country")
	  {
		  $scope.mandateforCountry();
		  	  
		  if($scope.countryMandate === false)
			  {
			  
			  if($scope.searchByCountryInput.COUNTRY === undefined || $scope.searchByCountryInput.COUNTRY === "--SELECT--")
				  {
				  $scope.searchByCountryInput.COUNTRY = '';
				  }
			  if($scope.searchByCountryInput.ITUPCODE === undefined )
			  {
			  $scope.searchByCountryInput.ITUPCODE = '';
			  }
			  if($scope.searchByCountryInput.PROVENCE === undefined )
			  {
			  $scope.searchByCountryInput.PROVENCE = '';
			  }
			  var tempcntry=null;
			  for(var i in $rootScope.espSearchfromAppKey){
			  	  if($scope.searchByCountryInput.COUNTRY===$rootScope.espSearchfromAppKey[i]){
			  		tempcntry=$rootScope.espSearchfromAppVal[i];
			  	  }
				  }  
			/*AllEspSearchSvc.searchByCountryDetails($scope.searchByCountryInput.COUNTRY,$scope.searchByCountryInput.ITUPCODE, $scope.searchByCountryInput.PROVENCE);*/
			  AllEspSearchSvc.searchBySearchCriteria("Country",null,tempcntry,
						$scope.searchByCountryInput.ITUPCODE, $scope.searchByCountryInput.PROVENCE,null,null,null,null,null,null,null,null);
			
			  }
  }
	  	
	  else if($scope.selectedOption.value === "Network")
	  {
		  $scope.mandateforNetwork();
		  $scope.focusToInvalidField();
	  
	  if($scope.networkITUMandate === false && $scope.networkCountryMandate === false)
		  {
		  
		  if($scope.searchByNetworkInput.COUNTRY === null || $scope.searchByNetworkInput.COUNTRY === '' || $scope.searchByNetworkInput.COUNTRY === undefined )
			  {
			  $scope.searchByCountryInput.COUNTRY = '';
			  }
		  if($scope.searchByNetworkInput.ItuCode === null || $scope.searchByNetworkInput.ItuCode === '' || $scope.searchByNetworkInput.ItuCode === undefined )
		  {
		  $scope.searchByNetworkInput.ItuCode = '';
		  }
		  if($scope.searchByNetworkInput.PopClli === null || $scope.searchByNetworkInput.PopClli === '' || $scope.searchByNetworkInput.PopClli === undefined )
		  {
		  $scope.searchByNetworkInput.PopClli = '';
		  }
		  if($scope.searchByNetworkInput.InterconnectType === null || $scope.searchByNetworkInput.InterconnectType === '' || $scope.searchByNetworkInput.InterconnectType === undefined || $scope.searchByNetworkInput.InterconnectType === "--SELECT--")
		  {
		  $scope.searchByNetworkInput.InterconnectType = '';
		  }
		  if($scope.searchByNetworkInput.EvcSpeed === null || $scope.searchByNetworkInput.EvcSpeed === '' || $scope.searchByNetworkInput.EvcSpeed === undefined )
		  {
		  $scope.searchByNetworkInput.EvcSpeed = '';
		  }
		  //AllEspSearchSvc.searchByNetworkDetails($scope.searchByNetworkInput.COUNTRY,$scope.searchByNetworkInput.ItuCode, $scope.searchByNetworkInput.PopClli,$scope.searchByNetworkInput.InterconnectType,$scope.searchByNetworkInput.EvcSpeed);
		  var tempcntry=null;
		  for(var i in $rootScope.espSearchfromAppKey){
	  	  if($scope.searchByNetworkInput.COUNTRY===$rootScope.espSearchfromAppKey[i]){
	  		tempcntry=$rootScope.espSearchfromAppVal[i];
	  	  }
		  }
		  AllEspSearchSvc.searchBySearchCriteria
			("Network",
			null,
			tempcntry,
			$scope.searchByNetworkInput.ItuCode,
			null,
			$scope.searchByNetworkInput.PopClli,
			$scope.searchByNetworkInput.InterconnectType,
			$scope.searchByNetworkInput.EvcSpeed,
			null,null,null,null,null);
		  
		  }
	  }
	  else if($scope.selectedOption.value === "Product"){
		  
		  $scope.mandateForProduct();
		  $scope.fnumber();
		  $scope.searchByProductInput.Product_Type = [];
		  if($scope.searchByProductInput.Lat === undefined){
			  $scope.searchByProductInput.Lat='';
		  }
		  if($scope.searchByProductInput.Long === undefined){
			  $scope.searchByProductInput.Long='';
		  }
		  if(($scope.searchByProductInput.Lat === null || $scope.searchByProductInput.Lat === '' || $scope.searchByProductInput.Lat === undefined) && 
				  !($scope.searchByProductInput.Long === null || $scope.searchByProductInput.Long === '' || $scope.searchByProductInput.Long === undefined))
		  {
			  $scope.searchByProductFlags.latitudeFlag= true;
		  }
		  if($scope.searchByProductInput.AGN_NODE === null || $scope.searchByProductInput.AGN_NODE === '' ||  $scope.searchByProductInput.AGN_NODE === undefined)
		  {
			  $scope.searchByProductInput.AGN_NODE='';
			  $scope.searchByProductFlags.AGN_NODEFlag= true;
		  }

		  if($scope.searchByProductInput.CMTU === null || $scope.searchByProductInput.CMTU === '' ||  $scope.searchByProductInput.CMTU === undefined)
		  {
			  $scope.searchByProductInput.CMTU='';
			  $scope.searchByProductFlags.CMTU= true;
		  }

		  if(($scope.searchByProductInput.Long === null || $scope.searchByProductInput.Long === '' || $scope.searchByProductInput.Long === undefined)
				  && !($scope.searchByProductInput.Lat === null || $scope.searchByProductInput.Lat === '' || $scope.searchByProductInput.Lat === undefined))
		  {
			  $scope.searchByProductFlags.longitudeFlag= true;
		  }
		  
		  if($scope.searchByProductFlags.CountryFlag === false && $scope.searchByProductFlags.CustomerSpeedFlag === false && $scope.searchByProductFlags.ProdTypeFlag === false &&  $scope.searchByProductFlags.ATTProductStatusFlag === false
			&& $scope.searchByProductFlags.latitudeFlag === false && $scope.searchByProductFlags.longitudeFlag === false && $scope.latFlag === false && $scope.longFlag === false && $scope.speedFlag ===false && $scope.CMTUflag === false)
		  {
			  for(i=0; i< $scope.prod_type_val.length;i++)
			  	{
			  		if($scope.prod_type_val[i] === null ||  $scope.prod_type_val[i] === '' || $scope.prod_type_val[i] === undefined)
			  		{
			  			$scope.prod_type_val.splice(i);
			  		}
			  	}
		  
			  if($scope.searchByProductInput.Country_Code === null || $scope.searchByProductInput.Country_Code === '' || $scope.searchByProductInput.Country_Code === undefined)
			  {
				  $scope.searchByProductInput.Country_Code = '';
			  }
			  if($scope.searchByProductInput.Cust_Speed === null || $scope.searchByProductInput.Cust_Speed === '' || $scope.searchByProductInput.Cust_Speed === undefined)
			  {
				  $scope.searchByProductInput.Cust_Speed = '';
			  }
			  if($scope.searchByProductInput.firstProdType === null || $scope.searchByProductInput.firstProdType === '' || $scope.searchByProductInput.firstProdType === undefined)
			  {
			 	$scope.searchByProductInput.firstProdType = '';
			  }
			  if($scope.searchByProductInput.ATT_Product_Status === null || $scope.searchByProductInput.ATT_Product_Status === '' || $scope.searchByProductInput.ATT_Product_Status === undefined)
			  {
				  $scope.searchByProductInput.ATT_Product_Status = '';
			  }
			  if(!($scope.searchByProductInput.firstProdType === null || $scope.searchByProductInput.firstProdType === '' || $scope.searchByProductInput.firstProdType === undefined))
			  { 
				  $scope.searchByProductInput.Product_Type.push($scope.searchByProductInput.firstProdType);
			  }
			  if(Object.keys($scope.prod_type_val).length > 0)
			  {
			  	$scope.searchByProductInput.Product_Type.push($scope.prod_type_val[0]);
			  }
			  	
			  $scope.searchByProductInput['attuid']= $cookieStore.get("attuid");
/*			  console.log('final Json to be sent to Search by product API : '+JSON.stringify($scope.searchByProductInput));*/
			  AllEspSearchSvc.searchBySearchCriteria
				("Product",
				null,
				$scope.searchByProductInput.Country_Code,
				$scope.searchByProductInput.AGN_NODE,
				null,
			    null,
				null,
				$scope.searchByProductInput.Cust_Speed,
				$scope.searchByProductInput.Lat,
				$scope.searchByProductInput.Long,
				$scope.searchByProductInput.Product_Type,
				$scope.searchByProductInput.CMTU,
				$scope.searchByProductInput.ATT_Product_Status
				);
		  }
	 }
  	
  	$rootScope.$on('prodDetDataObject', function (events,args) {
		 $rootScope.JsonProdDet = AllEspSearchSvc.prodDetData;
		 function objectToXml(obj) {
		        var xml = '';

		        for (var prop in obj) {
		            if (!obj.hasOwnProperty(prop)) {
		                continue;
		            }
		            
		            if (obj[prop] == undefined)
		                continue;
		            //if(isNaN(prop))
		           // xml += "<" + prop + ">";
		            if (typeof obj[prop] == "object")
		                xml += objectToXml(new Object(obj[prop]));
		            else
		            {
		            	if(obj[prop].length > 1){
		            		xml += obj[prop];
		            	}

		            }
		            //if(isNaN(prop))
		            //xml += "</" + prop + ">";
		        }
		        return xml;
		    }
			// End formatXml function
		 
		 var xmlString = "";
		 var xmlFinal=objectToXml($rootScope.JsonProdDet);
		 $rootScope.JsonProdDet=xmlFinal;
		 $rootScope.sml=xmlFinal;
		 $location.path('/ESPSearchResult/');
			 
	  });
  $rootScope.$on('countryDataObject', function (events,args) {
		// var data = AllEspSearchSvc.countryData;
		 $scope.JsonCountry = AllEspSearchSvc.countryData;
		 
		//formatXml function to format the response json to XML
		 function objectToXml(obj) {
		        var xml = '';

		        for (var prop in obj) {
		            if (!obj.hasOwnProperty(prop)) {
		                continue;
		            }

		            if (obj[prop] == undefined)
		                continue;
		            //if(isNaN(prop))
		           // xml += "<" + prop + ">";
		            if (typeof obj[prop] == "object")
		                xml += objectToXml(new Object(obj[prop]));
		            else
		            {
		            	if(obj[prop].length > 1){
		            		xml += obj[prop];
		            	}

		            }
		            //if(isNaN(prop))
		            //xml += "</" + prop + ">";
		        }
		        return xml;
		    }
			// End formatXml function
		 
		 var xmlString = "";
		 var xmlFinal=objectToXml( $scope.JsonCountry);
		 $scope.xmlString = xmlFinal; 
		 
		  $rootScope.JsonCountry =  $scope.xmlString;
		  $rootScope.JsonCountry1= $scope.JsonCountry;
		  $rootScope.sml=$scope.xmlString;

		 $location.path('/ESPSearchResult/');
			 
	  });
  
	$rootScope.$on('prodDataObject', function (events,args) {
		/* console.log("received response from service"+AllEspSearchSvc.prodData);*/
		/* console.log(AllEspSearchSvc.prodData);*/
		 $rootScope.JsonProd = AllEspSearchSvc.prodData;
		 function objectToXml(obj) {
		        var xml = '';

		        for (var prop in obj) {
		            if (!obj.hasOwnProperty(prop)) {
		                continue;
		            }
		            
		            if (obj[prop] == undefined)
		                continue;
		            //if(isNaN(prop))
		           // xml += "<" + prop + ">";
		            if (typeof obj[prop] == "object")
		                xml += objectToXml(new Object(obj[prop]));
		            else
		            {
		            	if(obj[prop].length > 1){
		            		xml += obj[prop];
		            	}

		            }
		            //if(isNaN(prop))
		            //xml += "</" + prop + ">";
		        }
		       /* console.log("xml--"+xml);*/
		        return xml;
		    }
			// End formatXml function
		 
		 var xmlString = "";
		 var xmlFinal=objectToXml($rootScope.JsonProd);
		 console.log("xmlFinal: "+xmlFinal);
		 $rootScope.JsonProd=xmlFinal;
		 $rootScope.sml=xmlFinal;
		 console.log("$scope.JsonProd: "+$rootScope.JsonProd);
		 $location.path('/ESPSearchResult/');
			 
	  });
  
  $rootScope.$on('networkDataObject', function (events,args) {
	  
	  //Fetch network data from the service
		var data= AllEspSearchSvc.networkData;
		$scope.JsonNetwork = AllEspSearchSvc.networkData;

		function objectToXml(obj) {
	        var xml = '';

	        for (var prop in obj) {
	            if (!obj.hasOwnProperty(prop)) {
	                continue;
	            }
	            
	            if (obj[prop] == undefined)
	                continue;
	            //if(isNaN(prop))
	           // xml += "<" + prop + ">";
	            if (typeof obj[prop] == "object")
	                xml += objectToXml(new Object(obj[prop]));
	            else
	            {
	            	if(obj[prop].length > 1){
	            		xml += obj[prop];
	            	}

	            }
	            //if(isNaN(prop))
	            //xml += "</" + prop + ">";
	        }
	        return xml;
	    }
		// End formatXml function

	
			var xmlFinal=objectToXml($scope.JsonNetwork);
			 $scope.xmlString = xmlFinal; 
			  $rootScope.JsonNetwork =  $scope.xmlString;
			  $rootScope.sml =$scope.xmlString;
			  
		 //   $rootScope.JsonNetwork=$scope.JsonNetwork;
		$location.path('/ESPSearchResult/'); 
		   
	 });
	 // $location.path('/searchESP/');
  }
  
  
  $scope.espSearchResetBtn = function()
  {
	 
	  //make the ng-model objects empty
      $scope.searchByCountryInput = {}; 
	  $scope.searchByProdDetail = {};
	  $scope.searchByProductInput = {};		
	  $scope.searchByNetworkInput = {};
	  
	  $scope.prod_type_val = [];
	  
	  $scope.submitFlag = false// submit flag reset
	  $scope.countryMandate = false;//reset country mandate flag
	  $scope.networkITUMandate = false;  //reset network ITU code mandate flag
	  $scope.networkCountryMandate = false; ////reset network country code mandate flag
	  
  } 
}
);

//Controller for ReportsCtrl page
app.controller('ReportsCtrl',
function ReportsCtrl($scope, $http, $log, $rootScope, $cookieStore, $location,GlobalLogonSvc, MessageSvc,ReportSvc,DropDownSvc,$timeout,$q) {
	
    userRoleTimer();
    $scope.selectedCriteria = {};
    $scope.myObj = { selectedItems : ""};
    function userRoleTimer(){
         
                   setTimeout(function(){
                    var actionList = $cookieStore.get("roles"); 
                    
                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
 $scope.$apply(function () {
	 
	 if(actionList.indexOf("CFGUPD") !== -1)
	 {
	 $rootScope.updateEspShow = true; 
	 $rootScope.isSuperAdmin = true;
	 console.log("user is a Super Admin");	
	 }	
	 else if(actionList.indexOf("ESPREPEDT") !== -1)
			{
		 $rootScope.updateEspShow = true; 
			console.log("user is a an Admin with role: ESPREPEDT");
			}
		else
			{
			console.log("no admin/super admin roles found, role found: ESPREPVW");	
			}
		DropDownSvc.dropDownValues("REP_TYPE");
        
           });
               		  
                      }

  },800);
     }
    
	$rootScope.whenOnhome=false;

	var espReportDD = [];


	$scope.criteriaCounter = null;
	
	var searchCriteriaDD = [];

$rootScope.$on('dropDownDataObject', function (events,args) {
		espReportDD=[];
	$rootScope.valuesData = DropDownSvc.dropDownData;

		for(var i in $rootScope.valuesData){
			
			if($rootScope.valuesData[i].key == "REP_TYPE"){
				searchCriteriaDD[i] = $rootScope.valuesData[i].values;
			}

			else{
			espReportDD[i]=$rootScope.valuesData[i].values;
			}
		
		}
	
	$scope.selectEspName = espReportDD;
	
	$scope.selectEspProduct = espReportDD;
	
	$scope.selectAttProduct = espReportDD;
	});

	$scope.selectOption = searchCriteriaDD;

	$scope.selectChange = function () {
		$scope.submitFlag = false;
		$scope.selectOpt = undefined;
		if($scope.selectedCriteria.value!=undefined){		
			DropDownSvc.dropDownValues($scope.selectedCriteria.value);
		}
	}; 

	$scope.selectedItem = function(value){
		$scope.selectOpt = value;		 
	}



	$scope.reportResetBtn = function () {
		$scope.myObj.selectedItems = undefined;
		$scope.selectOpt = undefined;
		$scope.submitFlag = false;
	}; 

	$scope.select = function ()
	{
		if($scope.selectOpt!=undefined && $scope.selectOpt!=null && $scope.selectOpt!=""){
			$scope.submitFlag=false;
			ReportSvc.updateReportGenerationDetails($scope.selectedCriteria.value,$scope.selectOpt);
		}	 
		else
		{
			$scope.submitFlag=true;
		}
	};
}
);



//Controller for searchTransaction page
app.controller('searchTransactionCtrl',
function searchTransactionCtrl($scope, $http, $log, $rootScope, $cookieStore, $location,$window,GlobalLogonSvc,DropDownSvc,MessageSvc, TransactionSvc, $window) {
	
var bck = null;

$scope.submitFlag=false;
userRoleTimer();
function userRoleTimer(){
     
               setTimeout(function(){
	                    var actionList = $cookieStore.get("roles"); 
	                    
	                      if(actionList === undefined)
	                      {
	                         	   userRoleTimer();
	                      }
		                  else
		                  {
							 $scope.$apply(function () {
								 if(actionList.indexOf("CFGUPD") !== -1)
								 {
								 $rootScope.updateEspShow = true; 
								 $rootScope.isSuperAdmin = true;
								 console.log("user is a Super Admin");	
								 }	 
								 else if(actionList.indexOf("SRCHTXNEDT") !== -1)
									{
									 $rootScope.updateEspShow = true; 
									 console.log("user is a an Admin with role: SRCHTXNEDT ");	
									}
									else
									{
										console.log("no admin/super admin roles found, role found: SRCHTXNVW");
									}
									if(bck == null || bck == undefined){
										
										DropDownSvc.dropDownValues("TXN_SEARCH");
								 }
							     });            		  
		                      }

              },800);
 }


$scope.selectedmainCriteria = {};
$rootScope.selectedmainCriteria = {};
$scope.selectedAPI = {value:""};
$scope.selectedApplication = {value:""};
$rootScope.selectedApplication = {};
$scope.Api = null;
$scope.ApiNme = null;
//$rootScope.selectedAPI = {};

$rootScope.countsearch = "1";
var txnTypeDD = [];
var apiNameDD = [];
var fromApplDD = [];
var hourDD = [];
var minuteDD = [];
var countForfromAppl = 1;
var countForHour = 0;
var countForMinute = 0;
// DropDownSvc.dropDownValues("TXN_SEARCH");

$scope.fromApi = function(value){
	  $scope.Api = value;
};

$scope.apiName = function(value){
	  $scope.ApiNme = value;
};

$scope.onSelectChange = function () 
{
	    countForfromAppl = 1;
	    countForMinute = 0;
	    countForHour = 0;
	    
	    var back3 = $rootScope.back;
	    var back4 = $rootScope.backdetail;
	   
	    if(back3!=null && back3!=undefined){
	    	$scope.selectedmainCriteria.value = back3;
	    	
	    }
	    else if(back4!=null && back4!=undefined){
	    	$scope.selectedmainCriteria.value = back4;
	    	
	    }
	    
	   	if($scope.selectedmainCriteria.value == "Transaction Details")
	   	{
	   		DropDownSvc.dropDownValues("TXN_DETAILS_SEARCH");
	   	}

		    $scope.FinalButtonFlag=true;
			$scope.TimeVal2ErrorFlag=false;
			$scope.TimeValErrorFlag=false;
			$scope.TransactionIDErrorFlag=false;
		    $scope.APIErrorFlag=false;
			$scope.StartHoursErrorFlag=false;
			$scope.StartMinutesErrorFlag=false;
			$scope.EndHoursErrorFlag=false;
			$scope.EndMinutesErrorFlag=false;
			$scope.DateErrorFlag=false;			
		    //$scope.selectedAPI=null;
		    $scope.TransactionId=null;
		    $scope.date=null;
		    $scope.StartDThour=null;
		    $scope.StartDTminute=null;
		    $scope.EndDThour=null;
		    $scope.EndDTminute=null;
		    //$scope.selectedApplication=null;
		    $scope.submitFlag=false;
};


      // $scope.onSelectChange();
      $rootScope.$on('dropDownDataObject', function (events,args) {
		espReportDD=[];
	    $rootScope.valuesData = DropDownSvc.dropDownData;
	    $rootScope.espSearchDDKey=[];
		$rootScope.espSearchDDVal=[];
		$rootScope.espSearchfromAppKey=[];
		$rootScope.espSearchfromAppVal=[];
		
		
		for(var i in $rootScope.valuesData){
			
			if($rootScope.valuesData[i].key == "TXN_SEARCH"){
				txnTypeDD[i] = $rootScope.valuesData[i].values;
			}	
			else if($rootScope.valuesData[i].key == "SCH_API_NM"){
				//apiNameDD[i] = $rootScope.valuesData[i].values;
				var criteria=[];
				if($rootScope.valuesData!=null){
					criteria=$rootScope.valuesData[i].values.split(':');
				}
				
				apiNameDD[i] = criteria[0];
				$rootScope.espSearchDDKey[i]=criteria[0];
				$rootScope.espSearchDDVal[i] = criteria[1];
			
				//apiNameDD[i]=$rootScope.espSearchDDKey[i];
				
			}
			else if($rootScope.valuesData[i].key == "HOUR_KEY"){
				hourDD[countForHour] = $rootScope.valuesData[i].values;
				countForHour = countForHour+1;
			}
			else if($rootScope.valuesData[i].key == "MINUTE_KEY"){
				minuteDD[countForMinute] = $rootScope.valuesData[i].values;
				countForMinute = countForMinute+1;
			}
			else if($rootScope.valuesData[i].key == "SRCH_APPL"){
				

				//apiNameDD[i] = $rootScope.valuesData[i].values;
				var criteria=[];
				if($rootScope.valuesData!=null){
					criteria=$rootScope.valuesData[i].values.split(':');
				}
				
				//apiNameDD[i] = criteria[0];
				$rootScope.espSearchfromAppKey[i]=criteria[0];
				$rootScope.espSearchfromAppVal[i]=criteria[1];
				
				fromApplDD[countForfromAppl] = $rootScope.espSearchfromAppKey[i];
				countForfromAppl = countForfromAppl+1;
			}
		}
	
		fromApplDD[0] = "--SELECT--"; 
		$scope.mainCriteriaOptions = txnTypeDD;
		$scope.optionTypeAPI = apiNameDD;
		$scope.optionTypeApplication = fromApplDD;
		$scope.hourTypeDt = hourDD;
		$scope.minuteTypeDt = minuteDD;
		
		 $rootScope.mainCriteriaOptions = $scope.mainCriteriaOptions;
		   $rootScope.optionTypeAPI = $scope.optionTypeAPI;
		   $rootScope.optionTypeApplication = $scope.optionTypeApplication;
		   $rootScope.hourTypeDt = $scope.hourTypeDt;
		   $rootScope.minuteTypeDt = $scope.minuteTypeDt;
	
	});


	$rootScope.whenOnhome=false;
	
	$scope.FinalButtonFlag=false;
	$scope.searchFlag = null;
	$scope.searchErrorFlag = false;

	$scope.TransactionIDErrorFlag=false;
	$scope.APIErrorFlag=false;
	$scope.StartHoursErrorFlag=false;
	$scope.StartMinutesErrorFlag=false;
	$scope.EndHoursErrorFlag=false;
	$scope.EndMinutesErrorFlag=false;
	$scope.DateErrorFlag=false;

	$scope.TimeValErrorFlag=false;
	$scope.TimeVal2ErrorFlag=false;
	
	
	
	var back4 = $rootScope.backdetail;
	
	var back2 = $rootScope.back;
	
	bck = $rootScope.back;
	if(back2 != null){ 
		$scope.selectedmainCriteria.value = back2; 
		$scope.FinalButtonFlag=true;
		
		$scope.mainCriteriaOptions = $rootScope.mainCriteriaOptions;
		$scope.optionTypeAPI = $rootScope.optionTypeAPI;
		$scope.optionTypeApplication = $rootScope.optionTypeApplication;
		$scope.hourTypeDt = $rootScope.hourTypeDt;
		$scope.minuteTypeDt = $rootScope.minuteTypeDt;
		
		$scope.date=$rootScope.date; 
		$scope.StartDThour= $rootScope.StartHr;
		$scope.StartDTminute = $rootScope.StartMin;
		$scope.EndDThour = $rootScope.EndHr;
		$scope.EndDTminute = $rootScope.EndMin;
		$scope.selectedApplication.value = $rootScope.Application;
		$scope.selectedAPI.value = $rootScope.selectedAPI;
		$scope.Api = $rootScope.Application;
		
		$scope.selectedAPI.value = $rootScope.selectedAPI;
		$scope.ApiNme = $rootScope.selectedAPI;
	} 
	else if(back2 == null && back4 !=null){
		$scope.selectedmainCriteria.value = back4; 
		$scope.FinalButtonFlag=true;
		$scope.TransactionId=$rootScope.TransactionId;
	}
	
	else{
		$scope.selectedmainCriteria.value = null;
	}
	$rootScope.back = null;
	$rootScope.backdetail = null;
	$rootScope.selectedmainCriteria.value= null; 	
  //$scope.selectedApplication=null;   


/******************************** START: Date Picker related Code ***************************/

$scope.today = function() {
	    $scope.dt = new Date();
	  };
	  $scope.today();

	  $scope.clear = function () {
	    $scope.dt = null;
	  };

	  // Disable weekend selection
	  $scope.disabled = function(date, mode) {
	    return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
	  };

	  $scope.toggleMin = function() {
	    $scope.minDate = $scope.minDate ? null : new Date();
  };  
	  $scope.toggleMin();

	  $scope.open = function($event) {
	    $event.preventDefault();
	    $event.stopPropagation();
  
  
	    if($scope.opened==true){
	    	$scope.opened=false;
	    }else{
	    	 $scope.opened = true;
	    }
	  };

	  $scope.dateOptions = {
	    formatYear: 'yy',
	    startingDay: 1
};
		
	  $scope.formats = ['MM/dd/yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	  $scope.format = $scope.formats[0];

/******************************** END: Date Picker related Code ***************************/

 
	  



/******************************** START: Code when User clicks SEARCH ***************************/	
$scope.SearchTransSubmit = function() {
	   
	
	   $rootScope.selectedmainCriteria.value = $scope.selectedmainCriteria.value;
	   $scope.checkTime= false;
	   $scope.submitFlag=true;
	   
	   var tempAPI = null;
	   var tempTransactionId=$scope.TransactionId;
	   var tempDate=$scope.date;
	   var tempStartHr=$scope.StartDThour;
	   var tempStartMin=$scope.StartDTminute;
	   var tempEndHr=$scope.EndDThour;
	   var tempEndMin=$scope.EndDTminute;
	   //var tempselectedApplication=$scope.selectedApplication.value;
	   var tempselectedApplication=$scope.Api;
     var ATTUID=$rootScope.attuid;
     
	  $rootScope.TransactionId=$scope.TransactionId;
    $rootScope.date = $scope.date;
    $rootScope.StartHr=$scope.StartDThour;
    $rootScope.StartMin=$scope.StartDTminute;
    $rootScope.EndHr=$scope.EndDThour;
    $rootScope.EndMin=$scope.EndDTminute;
    $rootScope.Application=$scope.Api;
    $rootScope.selectedAPI = $scope.ApiNme;
    
    for(var i in $rootScope.espSearchDDKey){
  	  if($scope.ApiNme===$rootScope.espSearchDDKey[i]){
  		  tempAPI=$rootScope.espSearchDDVal[i];
  	  }
    }
    
    for(var i in $rootScope.espSearchfromAppKey){
  	  if($scope.Api===$rootScope.espSearchfromAppKey[i]){
  		  tempselectedApplication=$rootScope.espSearchfromAppVal[i];
  	  }
    }
/*	   if($scope.ApiNme === "Country"){
	  	 //tempAPI = "RetrieveESPByCountry";
		   tempAPI = $rootScope.espSearchDDVal[0];
	   }
	   else if($scope.ApiNme === "Network"){
	  	 //tempAPI = "RetrieveESPByNetwolrk";
		   
	  	tempAPI = $rootScope.espSearchDDVal[1];
	   }
	   else if($scope.ApiNme === "Product"){
	  	// tempAPI = "RetrieveESPByProduct";
	  	tempAPI = $rootScope.espSearchDDVal[2];
	   }
	   else if($scope.ApiNme === "Product Details"){
	  	 //tempAPI = "RetrieveESPProductDetails";
		   tempAPI = $rootScope.espSearchDDVal[3];
	   }
*/	   
	   $scope.focusToInvalidFieldTxn=function(){
		   	  var field = null,
		   	  firstError = null;
		   	  for (field in $scope.EspTransactionForm) {
		   		  if (field[0] != '$')
		   		  {
		   			  if (firstError === null && $scope.EspTransactionForm[field].$invalid) {
		   				  firstError = $scope.EspTransactionForm[field].$name;
		   				
		   			  }

		   			  if ($scope.EspTransactionForm[field].$pristine) {
		   				  $scope.EspTransactionForm[field].$dirty = true;
		   			  }
		   		  }
		   	  }
		   	  $("#"+firstError).focus();
		     };
	   		   
		     
		     
	
	   if($scope.selectedmainCriteria.value==='Transaction ID')
	   {

		   //Call Web-service here for searching transactions as all validations are good
		   TransactionSvc.searchByTransactionID(tempTransactionId, ATTUID);

		   $rootScope.$on('transactionDataObject', function (events,args){	 
	   
			    var tempObj2 = this;
  	            this.transactionData2 = {};
			    tempObj2.transactionData2 = TransactionSvc.transactionDataObj;
	   
			    if(tempObj2.transactionData2!=null && tempObj2.transactionData2!="")
			    {
				   $rootScope.transactionJSON = tempObj2.transactionData2;
				   console.log("$rootScope.transactionJSON **111*: "+JSON.stringify($rootScope.transactionJSON));

	 				  
			       $rootScope.checkAPIFlag=false;
				   console.log("$rootScope.checkAPIFlag 1: "+$rootScope.checkAPIFlag);

				   if($rootScope.transactionJSON.apiName == 'RetrieveESPByProduct')
				   {
					   console.log("$rootScope.transactionJSON.apiName == 'RetrieveESPByProduct'");
				       $rootScope.checkAPIFlag=true;
				       
					   $rootScope.keyOtherParameter=$rootScope.transactionJSON.keyOtherParameter;
					   console.log("$rootScope.keyOtherParameter : "+JSON.stringify($rootScope.keyOtherParameter));
					   
					   var keyParams = $rootScope.keyOtherParameter;
					   var keyparamArray =keyParams.split(',');
					   
					   console.log('value sof key param array'+keyparamArray);
					   console.log('length'+keyparamArray.length);
					   
					   var keyParametersList=[];
					   for(var i=0;i<keyparamArray.length;i++){
						   
						   console.log('value of key param'+i+' '+keyparamArray[i]);
						   var coveragePriorityValues = keyparamArray[i].split(':');
						   
						   /*
						   $scope.keyParametersList[i].coverage=coveragePriorityValues[1];
						   $scope.keyParametersList[i].priority=coveragePriorityValues[2];*/
						   
						   var obj={
								   "coverage": coveragePriorityValues[1],
								   "priority": coveragePriorityValues[2]
						   };
						   
						   keyParametersList.push(obj);
						   
					   };
					   
					   
					   console.log('jsoncreated111 '+JSON.stringify(keyParametersList[0]));
					   
					   $rootScope.coveragePriorityList=keyParametersList;
					   
					   console.log('value of coverage prioeirty list in root scope: '+JSON.stringify($rootScope.coveragePriorityList));
				   }
				   console.log("$rootScope.checkAPIFlag 2: "+$rootScope.checkAPIFlag);
				   
				   

				   

				   // Go to Search Transaction Details page.
				   $location.path('/searchTransactionDetails/'); 
		        }	
			    else
			    {
				    MessageSvc.displayInfoMessage("No data found for requested Transaction ID.");
				    $('#info-msg').modal('show');
                  $("#info-msg").find("#okBtn").on("click", function () {
                });	
			     }
		    });
	   }
	   else if($scope.selectedmainCriteria.value==='Transaction Details')
	   {

		   if((tempAPI===null || tempAPI===undefined) || (tempStartHr===undefined || tempStartHr===null) || (tempStartMin===undefined || tempStartMin===null) || (tempEndHr===undefined || tempEndHr===null) || (tempEndMin===undefined || tempEndMin==null) || (tempDate===null || tempDate===undefined))
		   {
		 	   // console.log("Error : Some or all fields are empty");
			   // $scope.focusToInvalidFieldTxn();
		   }   
		   else
		   {
		   
		 		    $scope.APIErrorFlag=false;
		 			$scope.StartHoursErrorFlag=false;
		 			$scope.StartMinutesErrorFlag=false;
		 			$scope.EndHoursErrorFlag=false;
		 			$scope.EndMinutesErrorFlag=false;
		 			$scope.DateErrorFlag=false;
		 
		   
				   // Checking validation for date time here
				   $scope.TimeVal2ErrorFlag=false;
				   $scope.TimeValErrorFlag=false;
				   
				   if(tempEndHr >= tempStartHr && $scope.checkTime === false)
				   {
					   if(tempEndHr > tempStartHr)
					   {
						   if((tempEndHr-tempStartHr)===2 && (tempEndMin-tempStartMin)===0)
						   {
							       $scope.checkTime= true;
						   }
						   else if((tempEndHr-tempStartHr)===2 && (tempEndMin-tempStartMin)>0)
						   {
							       $scope.checkTime= false;
								   $scope.TimeValErrorFlag=true;
						   }
						   else if((tempEndHr-tempStartHr)>2)
						   {
							       $scope.checkTime= false;
								   $scope.TimeValErrorFlag=true;						   
						   }
						   else
						   {
							       $scope.checkTime= true;
						   }
					   }
					   else if(tempEndHr===tempStartHr)
					   {
						   if(tempEndMin > tempStartMin)
						   {
							   $scope.checkTime= true;
						   } 
						   else if(tempEndMin < tempStartMin)
						   {
							   $scope.checkTime= false;
							   $scope.TimeVal2ErrorFlag=true;
						   }
						   else
						   {
							   $scope.checkTime= true;
						   }
					   }
				   }
				   else if(tempEndHr < tempStartHr)
				   {
					       $scope.checkTime= false;
						   $scope.TimeVal2ErrorFlag=true;
				   }
			   
			   
			   
			       if($scope.checkTime === true)
				   {				   
					   var tempStartTime=tempStartHr+":"+tempStartMin;
					   var tempEndTime=tempEndHr+":"+tempEndMin;
		
					   //Call Web-service here for searching transactions as all validations are good		
			 		   
					   if(tempselectedApplication === "--SELECT--")
					   {
				 		   tempselectedApplication = 'null';
				 	   }
					   TransactionSvc.searchByTransactionDetails(tempAPI, tempDate, tempStartTime, tempEndTime, tempselectedApplication, ATTUID);
			 		   
			 		        $rootScope.$on('transactionallDetailsObject', function (events,args) {
				 			    
				 				var tempObj1 = this;
		                    	this.transactionData1 = {};
		      				    tempObj1.transactionData1 = TransactionSvc.transactionData;
		      				   
		      				    if(tempObj1.transactionData1!=null && tempObj1.transactionData1!="")
		      				    {
		      				        $rootScope.responseRetrieved={};
		      				    	$rootScope.dataArray=[];
				      				for(var i = 0; i < tempObj1.transactionData1.length; i++) 
				      				{
				      					$rootScope.responseRetrieved[i]=tempObj1.transactionData1[i].response[0]; 
				      					$rootScope.dataArray.push($rootScope.responseRetrieved[i]);
				      				}
				      				 window.localStorage.setItem("SearchTransactionData",JSON.stringify($rootScope.dataArray));
				      				 
				 				     // Go to Search Transaction Results page.
								     $location.path('/searchTransactionResult/'); 
		      				    }
		      				    else
		      				    {
		        				    MessageSvc.displayInfoMessage("No data found for requested Transaction details.");
		        				    $('#info-msg').modal('show');
		                            $("#info-msg").find("#okBtn").on("click", function () {
		                            });	
		      				     }
		      				    
								   console.log("$rootScope.dataArray ***: "+JSON.stringify($rootScope.dataArray));

		 			       });		 		 
			        }
		    }
	   }
	};

/******************************** END: Code when User clicks SEARCH ***************************/


/******************************** START: Code when User clicks RESET ***************************/

$scope.SearchTransReset = function() {
	   
     $scope.selectedAPI.value=null;
	   $scope.TransactionId=null;
	   $scope.date=null;
	   $scope.StartDThour=null;
	   $scope.StartDTminute=null;
	   $scope.EndDThour=null;
	   $scope.EndDTminute=null;
	   $scope.selectedApplication.value=null;

	   $scope.FinalButtonFlag=true;
	   
	   $scope.TimeVal2ErrorFlag=false;
	   $scope.TimeValErrorFlag=false;

	   $scope.submitFlag=false;
	  
	};
/******************************** END: Code when User clicks RESET ***************************/
}
);




//Controller for searchTransactionResult page
app.controller('searchTransactionResultCtrl',
function searchTransactionResultCtrl($scope, $http, $log, $rootScope,  $location, $window,MessageSvc, TransactionSvc,GlobalLogonSvc,  $window, Excel,$timeout) {
	 
		$rootScope.whenOnhome=false;
		
		$rootScope.back = $rootScope.selectedmainCriteria.value; 
		$scope.currentPage = 0;
		$scope.pageSize = 25;
		$scope.data = [];
		$scope.q = '';
		$rootScope.dataArray=JSON.parse(window.localStorage.getItem("SearchTransactionData"));
		
		$rootScope.dataTodisplay=$rootScope.dataArray.slice(($scope.currentPage*$scope.pageSize),($scope.currentPage+1)*$scope.pageSize) ;
		
		$scope.onPreviousPageClickPagination=function(){
			$scope.currentPage=$scope.currentPage-1;
			$rootScope.dataTodisplay=$rootScope.dataArray.slice(($scope.currentPage*$scope.pageSize),($scope.currentPage+1)*$scope.pageSize) ;
		};
		$scope.onNextPageClickPagination=function(){
			$scope.currentPage=$scope.currentPage+1;
			$rootScope.dataTodisplay=$rootScope.dataArray.slice(($scope.currentPage*$scope.pageSize),($scope.currentPage+1)*$scope.pageSize) ;
		};
		$scope.firstPagePagination=function(){
			$scope.currentPage=0;
			$rootScope.dataTodisplay=$rootScope.dataArray.slice(($scope.currentPage*$scope.pageSize),($scope.currentPage+1)*$scope.pageSize) ;
		};
		$scope.lastPagePagination=function(){
			$scope.currentPage= $scope.numberOfPages()-1;
			$rootScope.dataTodisplay=$rootScope.dataArray.slice(($scope.currentPage*$scope.pageSize),($scope.currentPage+1)*$scope.pageSize) ;
		};
		$scope.numberOfPages=function(){
		    return Math.ceil($rootScope.dataArray.length/$scope.pageSize);                
		};

	    
        $rootScope.countsearch = "2";
	      $scope.resultBackButton = function()
		  {
	    	  $location.path('/searchTransaction/'); 
		  };
		  
		  	  
		  $scope.statusClick = function(transactionJSON) 
		  {	  
			     var tempResultTransactionId=transactionJSON;
			     var tempATTUID=$rootScope.attuid;
	 		     
			     //Call Web-service here for searching transactions as all validations are good
	 		     TransactionSvc.searchByTransactionID(tempResultTransactionId, tempATTUID);
	 		     
	 		     $rootScope.$on('transactionDataObject', function (events,args) {	 
	 				   
		 			    var tempObj3 = this;
	          	        this.transactionData3 = {};
					    tempObj3.transactionData3 = TransactionSvc.transactionDataObj;
			   
					    if(tempObj3.transactionData3!=null && tempObj3.transactionData3!=""){
		 				   $rootScope.transactionJSON = tempObj3.transactionData3;
		 				   
						   console.log("$rootScope.transactionJSON ***: "+JSON.stringify($rootScope.transactionJSON));

		 				   $rootScope.checkAPIFlag=false;
						   console.log("$rootScope.checkAPIFlag 3: "+$rootScope.checkAPIFlag);

						   if($rootScope.transactionJSON.apiName == 'RetrieveESPByProduct')
						   {
							   console.log("$rootScope.transactionJSON.apiName == 'RetrieveESPByProduct'");
						       $rootScope.checkAPIFlag=true;
						       
						       $rootScope.keyOtherParameter=$rootScope.transactionJSON.keyOtherParameter;
							   console.log("$rootScope.keyOtherParameter : "+JSON.stringify($rootScope.keyOtherParameter));
							   
							   var keyParams = $rootScope.keyOtherParameter;
							   var keyparamArray =keyParams.split(',');
							   
							   console.log('value sof key param array'+keyparamArray);
							   console.log('length'+keyparamArray.length);
							   
							   var keyParametersList=[];
							   for(var i=0;i<keyparamArray.length;i++){
								   
								   console.log('value of key param'+i+' '+keyparamArray[i]);
								   var coveragePriorityValues = keyparamArray[i].split(':');
								   
								   /*
								   $scope.keyParametersList[i].coverage=coveragePriorityValues[1];
								   $scope.keyParametersList[i].priority=coveragePriorityValues[2];*/
								   
								   var obj={
										   "coverage": coveragePriorityValues[1],
										   "priority": coveragePriorityValues[2]
								   };
								   
								   keyParametersList.push(obj);
								   
							   };
							   
							   
							   console.log('jsoncreated111 '+JSON.stringify(keyParametersList[0]));
							   
							   $rootScope.coveragePriorityList=keyParametersList;
							   
							   console.log('value of coverage prioeirty list in root scope: '+JSON.stringify($rootScope.coveragePriorityList));
						   }
						   console.log("$rootScope.checkAPIFlag 4: "+$rootScope.checkAPIFlag);
		 				 
						   
						  
		 				   //Go to Search Transaction Details page.
		 				   $location.path('/searchTransactionDetails/'); 
		 		        }	
					    else
					    {
	    				    MessageSvc.displayInfoMessage("No data found for requested Transaction ID.");
	    				    $('#info-msg').modal('show');
	                        $("#info-msg").find("#okBtn").on("click", function () {
	                        });	
					    }
		 		});	   

		  };
		  
		  
		  
		  $scope.exportToExcel=function(tableId)
		  { 
				$scope.exportHref=Excel.tableToExcel(tableId,'Search Transaction Data');
				
				$timeout(function()
				{
					  location.href=$scope.exportHref;
					  },100); 
		   }
		  
		  
		  
		  /*  $scope.exportAsLink = function()   //function to download XML
		    {
		    	var element = document.createElement('a');
		        var blob = new Blob([$scope.exportHref], {
		          type: 'text/xml'
		        });
		        
		        var url = URL.createObjectURL(blob);
		        element.href = url;
		        element.setAttribute('download', 'Search_Transaction_Data.xls');
		        document.body.appendChild(element); 
		        element.click();
		       
		      }
         */
		  
}
);

	 
	 
//Controller for searchTransactionDetails page
app.controller('searchTransactionDetailsCtrl',
function searchTransactionDetailsCtrl($scope, $http, $log, $rootScope,  $location, MessageSvc, TransactionSvc, GlobalLogonSvc,XMLGenSvc, $window) {
	  
	  
	  $rootScope.whenOnhome=false;
	  $rootScope.backdetail = $rootScope.selectedmainCriteria.value;
	  
	  $scope.ReqXMLSubmit = function() 
	  {

	    	var element = document.createElement('a');
	        var blob = new Blob([$rootScope.transactionJSON.requestXML], {
	          type: 'text/plain'
	        });
	        var url = URL.createObjectURL(blob);
	        element.href = url;
	        element.setAttribute('download', 'TransactionRequest.txt');
	        document.body.appendChild(element); 
	        element.click();
	   };
	  
	  
	  $scope.ResXMLSubmit = function() 
	  {
	    	var element = document.createElement('a');
	        var blob = new Blob([$rootScope.transactionJSON.responseXML], {
	          type: 'text/plain'
	        });
	        var url = URL.createObjectURL(blob);
	        element.href = url;
	        element.setAttribute('download', 'TransactionResponse.txt');
	        document.body.appendChild(element); 
	        element.click();

	   };   
	   
	   
	     $scope.backButton = function()
		 {  
		  	  if($rootScope.countsearch === "2") 
		  	  { 
		  	      $location.path('/searchTransactionResult/'); 
		  	  } 
		  	  else if($rootScope.countsearch === "1")
		  	  { 
		  		  $location.path('/searchTransaction/');
		  	  }
		  };
		  
		  
		$scope.LoadXMLStringReq = function (ParentElementID) 
		{
			xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.transactionJSON.requestXML);
			return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
		};
		
		$scope.LoadXMLStringRes = function (ParentElementID) 
		{
			xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.transactionJSON.responseXML);
			return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
		};
}
);








app.controller('SearchResultCtrl',
function SearchResultCtrl($scope ,$http, $log, $rootScope, $window, $location,$timeout,$scope, MessageSvc,DropDownSvc,myService,AllEspSearchSvc,GlobalLogonSvc,Excel,XMLGenSvc){
	$rootScope.whenOnhome=false;
	$rootScope.backValue = null;
	$rootScope.backValue=$rootScope.selectedOption.value;
	$scope.JsonCountry1=$rootScope.JsonCountry1;
	//var searchTypeDD = [];
//	DropDownSvc.dropDownValues("ESP_SEARCH_TYPE");
	/*$rootScope.$on('dropDownDataObject', function (events,args) {
		
		$rootScope.valuesData = DropDownSvc.dropDownData;

			for(var i in $rootScope.valuesData){
				
				if($rootScope.valuesData[i].key == "SCH_API_NM"){
					searchTypeDD[i] = $rootScope.valuesData[i].values;
				}
				
			}
			
			$scope.optionType = searchTypeDD;
			$rootScope.optionType = searchTypeDD;
								
		});*/
	
	$scope.exportBtn = function()
	{
		if($rootScope.selectedOption.value === 'Country')
			{
			console.log('here1 ');
			 var exportHref=Excel.tableToExcel('#countryTable','SearchByCountryResult');
        	 $timeout(function(){location.href=exportHref;},100); // trigger download
			$scope.exportAsLinkCountry();
			}
		else{
				$scope.exportAsLink();
			}
	}
/*	$scope.exportToExcel=function(tableId){ 
        var exportHref=Excel.tableToExcel(tableId,'SearchByCountryResult');
        $timeout(function(){location.href=exportHref;},100); // trigger download
    };*/
	
	$scope.file = $rootScope.sml;
	
    $scope.exportAsLink = function()   //function to download XML
    {
    	var element = document.createElement('a');
        var blob = new Blob([$scope.file], {
          type: 'text/xml'
        });
        var url = URL.createObjectURL(blob);
        element.href = url;
        element.setAttribute('download', 'ESP.xml');
        document.body.appendChild(element); 
        element.click();
       
      }
    
/*    $scope.fileCountry  = $rootScope.smlCountry;
    $scope.exportAsLinkCountry = function()   //function to download XML
    {
    	var element = document.createElement('a');
        var blob = new Blob([$scope.fileCountry], {
          type: 'text/xml'
        });
        var url = URL.createObjectURL(blob);
        element.href = url;
        element.setAttribute('download', 'ESPByCountry.xml');
        document.body.appendChild(element); 
        element.click();
      }*/
    
	$scope.LoadXMLString = function (ParentElementID)  // function to show XML as collapsible
	{
		xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.JsonNetwork);
		return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
	}
	
	$scope.LoadXMLStringPD = function (ParentElementID)  // function to show XML as collapsible
	{
		xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.JsonProdDet);
		return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
	}
	  /*$scope.LoadXMLStringCountry = function (ParentElementID)  // function to show XML as collapsible
		{
			xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.JsonCountry);
			return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
		}*/
	  	$scope.LoadXMLStringProd = function (ParentElementID)  // function to show XML as collapsible
		{
			xmlDoc = XMLGenSvc.CreateXMLDOM($rootScope.JsonProd);
			return XMLGenSvc.LoadXMLDom(ParentElementID,xmlDoc);
		}
	
	  $scope.backBtn = function()
	  {
		  $location.path('/searchEsp/');
		  //$window.history.back();
	  }
	  
}
);

app.controller('addSupportCtrl',
		function addSupportCtrl($scope ,$log ,$location, $rootScope,$cookieStore, MessageSvc,DropDownSvc,AddSupportSvc,GlobalLogonSvc,myService,$http){
	
	userRoleTimer();
	//Start of user role timer
    function userRoleTimer(){
         
                   setTimeout(function(){
                    var actionList = $cookieStore.get("roles"); 
                    
                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
                    	  $scope.$apply(function () {
                 			 
                    		  if(actionList.indexOf("CFGUPD") !== -1)
                    			 {
                    			 $rootScope.updateEspShow = true; 
                    			 $rootScope.isSuperAdmin = true;
                    			 console.log("user is a Super Admin");	
                    			 }	
                    		  else if(actionList.indexOf("SUPUPDT") !== -1)
                    		  	{
                    		  	$rootScope.updateEspShow = true; 
                    		  	console.log("User is an admin with role: SUPUPDT ");	
                    		  	//DropDownSvc.dropDownValues("SUPPORT_TYPE");
                    			//GetSupportDetailsSvc.getSupportDetails($scope.updateSupportInput.type,attuid);
                    		  	}
                    		  else
                    		  	{
                    		  	$location.path('/home/');
                    		  	console.log("no admin/super admin roles found");		
                    		  	}

                    		             });
               		  
                      }

  },800);
     }
    //end of user role timer
	$rootScope.whenOnhome=false;
	$scope.add = {};
	$scope.add.selectedSupportType = null;
	$scope.faqInput = {};
	$scope.refInput = {};
	$scope.add.selectedCategory = null;
	
	$scope.supportFAQFlag = false;
	 $scope.supportREFflag=false;
	 $scope.categoryFlag = false;
	 $scope.finalBtnFlag = false;
	 
	/*$scope.optionForSupport = [{text: "--Start--",value: "blank"},
                      {text: "REF",value: "REF"},
                      {text: "FAQ",value: "FAQ"}];*/
	
	var espSupportFaqDD=[];
	var espSupportRefDD=[];
	var espSupporTypeDD=[];
	var countForFaq=0;
	var countForRef=0;
	DropDownSvc.dropDownValues("ADD_SUPPORT");
	$rootScope.$on('dropDownDataObject', function (events,args) {
		
	$rootScope.valuesData = DropDownSvc.dropDownData;
		for(var i in $rootScope.valuesData){
			if($rootScope.valuesData[i].key!=null){
				espSupporTypeDD[i] = $rootScope.valuesData[i].key;
			}
						
			if($rootScope.valuesData[i].key === "FAQ"){
				espSupportFaqDD[countForFaq] = $rootScope.valuesData[i].values;
				countForFaq = countForFaq+1;
			}

			else if($rootScope.valuesData[i].key === "REF"){
				espSupportRefDD[countForRef] = $rootScope.valuesData[i].values;
			    countForRef = countForRef+1;
			}
		
		}
		espSupportRefDD[0] = "Add new...";
		espSupportFaqDD[0] = "Add new...";
		var uniqueNames = [];
		$.each(espSupporTypeDD, function(i, el){
		    if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
		});
	$scope.optionForSupport = uniqueNames;
	});
	
	 $scope.onSelectChangeSupport = function () 
	  {
		 $scope.add.selectedCategory=null;
		 $scope.addFlag = false; 
		 $scope.finalBtnFlag = true;
		 // console.log('$scope.add.selectedSupportType: '+$scope.add.selectedSupportType);
		  if($scope.add.selectedSupportType == "FAQ")
		  {
			  //console.log("IN FAQ++++++++++");
			    $scope.supportFAQFlag=true;
		  }
		  if($scope.add.selectedSupportType == "REF")
		  {
			 // console.log("IN REF++++++++++");
			  $scope.supportREFflag=true;
		  }
		  
			if($scope.add.selectedSupportType === "FAQ"){
				$scope.optionForSupport1 = espSupportFaqDD;
				
			}
			else if($scope.add.selectedSupportType === "REF"){
				$scope.optionForSupport1 = espSupportRefDD;
			}
	
	  
	  };

	  $scope.onSelectChangeCategory = function(){
			// console.log("++++onSelectChangeCategory++++++++ "+$scope.add.selectedCategory);
			 // $scope.addFlag = false; 
			if(!($scope.add.selectedCategory === "Add new...") && $scope.add.selectedCategory != undefined && $scope.add.selectedCategory != null){
				console.log("in if part: ");
				 $scope.categoryFlag = true;
				 console.log("value of flag in if part: "+$scope.categoryFlag);
			}
			else{
				
				 $scope.categoryFlag = false;
				 console.log("value of flag: "+$scope.categoryFlag);
			}
		  }
	  
	  $scope.addValue = function (){
		  $scope.addFlag = true; 
		  $scope.finalBtnFlag = true;
		 // $scope.categoryFlag = true;
		  
		  
		  if(!($scope.add.selectedCategory === null || $scope.add.selectedCategory === '' || $scope.add.selectedCategory === undefined)){
			  
			  if($scope.add.selectedSupportType == 'REF'){
				  if($scope.add.selectedCategory != 'Add new...'){
					  $scope.refInput.CATEGORY = $scope.add.selectedCategory ;  
				  }
			  }else{
				  if($scope.add.selectedCategory != 'Add new...'){
					  $scope.faqInput.CATEGORY =  $scope.add.selectedCategory ;  
				  }
			  }
			  
			  
			  //console.log("$scope.faqInput.CATEGORY faqInput++++"+$scope.faqInput.CATEGORY ); 
			 // console.log("$scope.faqInput.CATEGORY refInput++++"+$scope.refInput.CATEGORY ); 
		  }
		 
 
		  if($scope.add.selectedSupportType === null || $scope.add.selectedSupportType === '' || $scope.add.selectedSupportType === undefined){ 
			  console.log("addFlag"+$scope.addFlag); 
		  } 
		  else 
		  { 
			  $scope.supportFAQFlag = true; 
			  $scope.supportREFflag = true; 
 
			  if((($scope.faqInput.CATEGORY === null || $scope.faqInput.CATEGORY === '' || $scope.faqInput.CATEGORY === undefined) 
					  || ($scope.faqInput.QUESTION === null || $scope.faqInput.QUESTION === '' || $scope.faqInput.QUESTION === undefined) 
					  || ($scope.faqInput.ANSWER === null || $scope.faqInput.ANSWER === '' || $scope.faqInput.ANSWER === undefined))
					  
					  && $scope.add.selectedSupportType === "FAQ" ) 
				  
				  { 
				
				  $scope.addFlag = true; 
				  } 
			  else if((($scope.refInput.CATEGORY === null || $scope.refInput.CATEGORY === '' || $scope.refInput.CATEGORY === undefined) 
					  || ($scope.refInput.TITLE === null || $scope.refInput.TITLE === '' || $scope.refInput.TITLE === undefined) 
					  || ($scope.refInput.LINK === null || $scope.refInput.LINK === '' || $scope.refInput.LINK === undefined))
					  
					  && $scope.add.selectedSupportType === "REF" ) 
				  
				  { 
				  $scope.addFlag = true; 
				  } 
			  else{ 
				 // console.log("+++++++++++++++++++IN ELSE");
				  if(!$rootScope.notURL)
				  AddSupportSvc.addSupportDetails($scope.faqInput.CATEGORY,$scope.faqInput.QUESTION,$scope.faqInput.ANSWER,$scope.faqInput.DESCRIPTION,
						  $scope.refInput.CATEGORY,$scope.refInput.TITLE,$scope.refInput.LINK,$scope.refInput.DESCRIPTION); 
				  console.log("value of CATEGORY in ref: "+ $scope.refInput.CATEGORY+" and in faq: "+$scope.faqInput.CATEGORY);
			  } 
		} 
		  
	 $rootScope.$on('addSupportDataObject', function (events,args) {
		 console.log("received response from service"+AddSupportSvc.addSupportData);
		 console.log(AddSupportSvc.addSupportData);
		 $scope.JsonCountry = AddSupportSvc.addSupportDetails;
		  }
	  ) 
	 // console.log("AFTER ADD+++++++++++++");
	  }
	  
	  
	  
	  $scope.addSupportResetBtn = function()
	  {
		 
		  //make the ng-model objects empty
	      $scope.faqInput = {}; 
	      $scope.refInput = {}; 
	      $scope.refInput.LINK = null;
	      $scope.add.selectedCategory = null;
	      
		  $scope.addFlag = false// add flag reset		  
	  } 
	  
}
);


app.controller('updateSupportCtrl',
		function updateSupportCtrl($scope ,$http, $log, $rootScope,$cookieStore, $window, $location,$timeout,$scope, MessageSvc,DropDownSvc,myService,GlobalLogonSvc,GetSupportDetailsSvc,DeleteSupportSvc,UpdateSupportSvc){
	console.log('Inside update support ctrl');
	
	
	$scope.updateSupportInput={};
	$rootScope.whenOnhome=false;
	$scope.submitFlag=false;
    console.log('value of session storage on refresh : '+sessionStorage.getItem("deletedRecord"));
	if(sessionStorage.getItem("deletedRecord") == 'REF'){
		//console.log('inside local storage ref');
		$scope.updateSupportInput.type="REF";
	}else{
		//console.log('inside local storage faq');
		$scope.updateSupportInput.type="FAQ";
	}
	
	userRoleTimer();
	//Start of user role timer
    function userRoleTimer(){
         
                   setTimeout(function(){
                    var actionList = $cookieStore.get("roles"); 
                    
                      if(actionList === undefined)
                      {
                         	   userRoleTimer();
                      }
                      else{
                    	  $scope.$apply(function () {
                    			 
                    		  if(actionList.indexOf("SUPUPDT") !== -1)
                    		  	{
                    		  	$rootScope.updateSupportShow = true; 
                    		  	console.log("action role for updateSupportCtrl: SUPUPDT ");	
                    		  	DropDownSvc.dropDownValues("SUPPORT_TYPE");
                    			GetSupportDetailsSvc.getSupportDetails($scope.updateSupportInput.type,attuid);
                    		  	}
                    		  else
                    		  	{
                    		  	$location.path('/home/');
                    		  	console.log("no role present in UpdateSupportCtrl");	
                    		  	}

                    		             });
		
                      }

  },800);
     }
    //end of user role timer
   
    var attuid = $cookieStore.get("attuid").toLowerCase();
    console.log('value of attuid1 : '+attuid);
    
    //start of on changefunction of select type dd
    $scope.selectTypeChange = function (){
    	console.log('Inside select change of update support, value of dd :'+$scope.updateSupportInput.type);
    	
    	if($scope.updateSupportInput.type === 'REF'){
    		if($scope.eSPGetSupportDetails.ref == null){
    			console.log('reference is null so calling get support service');
    			GetSupportDetailsSvc.getSupportDetails("REF",attuid);
    		}
    	}else if ($scope.updateSupportInput.type === 'FAQ'){
    		if($scope.eSPGetSupportDetails.faq == null){
    			console.log('faq is null so calling get support service');
    			GetSupportDetailsSvc.getSupportDetails("FAQ",attuid);
    		}
    	}
    }
   //end of change function
    
    //start of updatefunction
    $scope.updateRecords = function(data){
    	//console.log('Inside update click function to open pop up122 window data send' +JSON.stringify(data));
    	
    	sessionStorage.updateSupportData = JSON.stringify(data);
    	$scope.updateSupportPopUp=JSON.parse(sessionStorage.updateSupportData);
    	
    	var deletedRecordType =$scope.updateSupportInput.type;
		sessionStorage.setItem("deletedRecord", deletedRecordType);
		
		//command to open modal window for update support pop up
		 $('#update-detail').modal('show');
                 
    }
    //end of update function
    
    //start of delete record function
    $scope.deleteRecord = function (recordId)  
	{
    	$scope.updateSupportInput.functionType="delete";
		console.log('inside delete function record id to be deleted : '+recordId);
		$('#update-cnfrm').modal('show');
		
		$("#update-cnfrm").find("#okUpdate").on("click", function () {
			DeleteSupportSvc.deleteSupportRecord(attuid,recordId);
			 var deletedRecordType =$scope.updateSupportInput.type;
			 sessionStorage.setItem("deletedRecord", deletedRecordType);
			
        	
		});
		$("#update-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#update-cnfrm').modal('hide');
        });
	}
    //end of delete record function
    
  
    $scope.updateSupportTypeDD = [];    
    $scope.eSPGetSupportDetails={};
    
    //on function to get DD value
    $rootScope.$on('dropDownDataObject', function (events,args) {
    	
    	$rootScope.valuesData = DropDownSvc.dropDownData;
    		for(var i in $rootScope.valuesData){
    			
    			if($rootScope.valuesData[i].key == "SUPPORT_TYPE"){
    				$scope.updateSupportTypeDD[i] = $rootScope.valuesData[i].values;
    			}
    		}
    		//console.log('value of request type dd '+JSON.stringify($scope.updateSupportTypeDD));
    });
    //end of on function to populate DD
    
    //to get records from this service data should be their corrosponding to your attuid
    //GetSupportDetailsSvc.getSupportDetails($scope.updateSupportInput.type,attuid);
    
    
    //Start of ON function to populate Data fetched from getSupportDetailSvc
    $rootScope.$on('supportDetailsDataObject', function (events,args) {
    	$rootScope.valuesData = GetSupportDetailsSvc.supportDetailsData;
    	$scope.eSPGetSupportDetails.faq=$rootScope.valuesData[0].responseFaq;
    	$scope.eSPGetSupportDetails.ref=$rootScope.valuesData[0].responseRef;
    	//console.log("value of support data in controller : "+JSON.stringify($rootScope.valuesData));
    });
    //end of ON function to fetch get support data
    
    
  //Start functions for the update pop up
    $scope.closeWindow = function (){
    	
    	$('#update-detail').modal('hide');
	}
	
	//function to reset data in pop up window
	$scope.resetUpdateSupport = function(){
		$scope.updateSupportPopUp=JSON.parse(sessionStorage.updateSupportData);
	}
	
	//function to update the record in the pop up
	$scope.updateSupportRecord = function(){
		$scope.submitFlag=true;
		$scope.updateSupportInput.functionType="update";
		console.log('Update function triggered');
		//console.log('values to bee1 updated '+JSON.stringify($scope.updateSupportPopUp));
		if(($scope.updateSupportPopUp.title == null || $scope.updateSupportPopUp.category == null || 
			 $scope.updateSupportPopUp.link == null|| $scope.updateSupportPopUp.title == undefined || 
			 $scope.updateSupportPopUp.link == undefined || $scope.updateSupportPopUp.link == "" || $scope.updateSupportPopUp.title == "" || $scope.updateSupportPopUp.category == ""
				 || $scope.updateSupportPopUp.category == undefined) && $scope.updateSupportInput.type=='REF'){
				$scope.updateErrorMsg=true;
		}
		else if(($scope.updateSupportPopUp.question == null || $scope.updateSupportPopUp.category == null || 
					 $scope.updateSupportPopUp.answer == null|| $scope.updateSupportPopUp.question == undefined || 
					 $scope.updateSupportPopUp.answer == undefined ||  $scope.updateSupportPopUp.answer == "" || $scope.updateSupportPopUp.question == "" || 
					 $scope.updateSupportPopUp.category == "" || $scope.updateSupportPopUp.category == undefined) && $scope.updateSupportInput.type=='FAQ'){
			$scope.updateErrorMsg=true;
		}
		else{
			 if(!$rootScope.notURL){
				 
			 
		$('#update-cnfrm').modal('show');
		
		$("#update-cnfrm").find("#okUpdate").on("click", function () {
        	UpdateSupportSvc.updateSupportRecord($scope.updateSupportPopUp,$scope.updateSupportInput.type,attuid);
        	
		});
		$("#update-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#update-cnfrm').modal('hide');
        });
			 }
		}
	}
    		
}
);
//end for update support page controller



app.controller('viewSupportCtrl',
		function viewSupportCtrl($scope, $http, $log, $rootScope,  $location, MessageSvc, TransactionSvc,GlobalLogonSvc,ConfigSvc, $cookieStore, $window){	
	console.log("***** viewSupportCtrl Start *****");	
	
	this.tab = 1;
    this.setTab = function (tabId) {
        this.tab = tabId;
    };
    this.isSet = function (tabId) {
        return this.tab === tabId;
    };   
    var attuid = $cookieStore.get("attuid").toLowerCase();
    
    $rootScope.whenOnhome=false;
     $scope.reference = false;
     $scope.faq = false;
     $scope.openAllDivs = false;
	 $scope.opened = false;
	 $scope.setOpened = function(val) {		  
	 $scope.opened = val;		
	 };	
	  $scope.setOpenedMainDiv = function(val) {	
	  $scope.openAllDivs = true;		 
	  if(val=='ref'){	
		  ConfigSvc.getConfig(function (cfg) {
			var webSRCPath = ConfigSvc.getAbsPath();
			var GetSupporturlForRef = webSRCPath + cfg.viewSupport;
			var param=new FormData();
			var url=GetSupporturlForRef;		
			var param=new FormData();   	 	
    	 	console.log("url to connect to service: "+url);
    		param.append('attuId', attuid);
    		param.append('type','REF');	    			
    		//$rootScope.$broadcast('BusyStart');    			
    			$http.post(url, param, {
    				transformRequest: angular.identity,
    				headers: {'Content-Type': undefined}
    			})
    			.then( function(response) {
    				//$rootScope.$broadcast('BusyEnd');
    				$scope.results =response.data.eSPGetSupportDetailsRef;	   				
    			});	
    			$scope.reference = true;
    			$scope.faq = false;
		  });
	  }else {			
			 ConfigSvc.getConfig(function (configFaq) {
					var webSRCPath = ConfigSvc.getAbsPath();					
					var GetSupportUrlForFaq = webSRCPath + configFaq.viewSupport;
					var param=new FormData();
					var url=GetSupportUrlForFaq;					
					 $scope.reference = false;
					  $scope.faq = true;
					  var param=new FormData();			     	 	
			     	 	console.log("url to connect to service: "+url);
			     	 	param.append('attuId', attuid);
			     		param.append('type','FAQ');		     			
			     		//$rootScope.$broadcast('BusyStart');	     			
			     			$http.post(url, param, {
			     				transformRequest: angular.identity,
			     				headers: {'Content-Type': undefined}
			     			})
			     			.then( function(response) {
			     				//$rootScope.$broadcast('BusyEnd');
			     				$scope.results =response.data.eSPGetSupportDetailsFaq;		
			     		});	
			 	});
	  	}
	   
	  };
	  $scope.setOpenedDiv = function(val1,val2) {		  
		  angular.forEach($scope.results, function (value, key) {
	           if(value.category==val1){
	        	   if(val2 == false){
	        		   value.open = true;
	        	   }else {
	        		   value.open = false;
	        	   }	        	  
	           }
	        });
	  };	  
	  $scope.setOpenedAllDiv = function() {		
		  angular.forEach($scope.results, function (value, key) {
			  if($scope.openAllDivs == false ){
				  value.open = true;				  
			  }else {
				  value.open = false;
				  
			  }
	        });
		  if($scope.openAllDivs == false ){
			  $scope.openAllDivs  = true;
		  }else {
			  $scope.openAllDivs  = false;
		  }
	  };	
	  $scope.setOpenedMainDiv('ref');	  
      console.log("***** searchTransactionResultCtrl End *****");     

}
);



app.controller('uploadMoWBuildingListCtrl',
	function uploadMoWBuildingListCtrl($scope, $http, $rootScope, $cookieStore, GlobalLogonSvc,DropDownSvc,$location,MessageSvc,RoleSvc, uploadSvcMoW) {
	
console.log("*** uploadMoWBuildingListCtrl Start ***");
	
	var coverageName = $scope.coverageName; 
	var bufferRadius = $scope.bufferRadius; 
	var geoCodingThreshold = $scope.geoCodingThreshold; 
	var technologyType = $scope.technologyType; 
	var fullRefresh = $scope.fullRefresh; 

	
	$scope.downloadTemplate = function () { 
	   	$('#iframeviewMoW').html('<iframe src="images/ESP_MoW_Template.xlsx"></iframe>'); 
		}
	
	$scope.submitFlagMoW=false;
	
	// for showing only .xml files are allowed
	$scope.LoadRefFileFlagEmpty = false; 

	//file select mandate
	$scope.LoadRefFileFlagMoW = null;
	
	
	//function to check if the file is selected for upload
	$scope.fileSelectMoW = function ()
	{
	    $("input:file").change(function () {
	        $scope.LoadRefFileFlagMoW = false;
	        $("#fileErrorMsg").css("display", "none"); // hide the error msg id
	    });

	};
	
		
	$scope.LoadRefDdFuncMoW = function (fileChoose)
	{
		$scope.submitFlagMoW=true;
		
	    $scope.selectedFile = fileChoose;
	    var fileUpLoadBrowse = "#" + fileChoose;
	    
	    if ($(fileUpLoadBrowse)[0].files[0] === undefined || $(fileUpLoadBrowse)[0].files[0] === null) 
	    {
	        $scope.LoadRefFileFlagMoW = true;
	        console.log("Please Select a file.");
	        return;
	    }
	    else
	    {   
	          console.log("File selected!");
	    	  $scope.LoadRefFileFlagMoW = false;
  	    	  $scope.LoadRefFileFlagEmptyMoW = false;
        	  $scope.LoadRefFileFlagZeroMoW=false;	

	          var filename= document.getElementById("fileUpLoadBrowse").files;
	  	      var fileHandle = $(fileUpLoadBrowse)[0].files[0];
	  	      console.log("filename100: "+fileHandle);
	  	      var filePath = $(fileUpLoadBrowse).val();
	  	      var fileName = filePath.split(/(\\|\/)/g).pop(); //Gets the file name from the  path
	  	      var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
	  	      console.log("file extension: " + ext);
	  	    
	    	  if(filename[0].size==0)
	          {
	          	$scope.LoadRefFileFlagZeroMoW=true;
		        console.log("The file is empty, please check and upload a valid file again.");
	          }
	          else
	          {
	          	    $scope.LoadRefFileFlagZeroMoW=false;	
	        	    if (ext == 'xlsx')
	        	    {
	        	    	$scope.LoadRefFileFlagEmptyMoW = false;
	        	    	
	        	    	//Calling service to Upload
	        	    	if((coverageName==null || coverageName==undefined) || (bufferRadius==null || bufferRadius==undefined) || (geoCodingThreshold==null || geoCodingThreshold==undefined) || (fileHandle==null || fileHandle==undefined))
	        	    	{
		        	    	console.log("Something is Null!!");
	        	    	}
	        	    	else
	        	    	{
		        	    	console.log("Calling service to Upload");
		        	    	uploadSvcMoW.uploadFileMoW(coverageName, bufferRadius, geoCodingThreshold, technologyType, fullRefresh, fileHandle);
	        	    	}
	        	    }
	        	    else
	        	    { 
	        	    	console.log("File is of Invalid Format!");
	        	    	$scope.LoadRefFileFlagEmptyMoW = true;
	    	        }
	          }
	     }
	}
	
console.log("*** uploadMoWBuildingListCtrl End ***");

});


app.controller('configParamCtrl',
		function configParamCtrl($scope, $http, $rootScope, $cookieStore, GlobalLogonSvc,ConfigSvc,DropDownSvc,$location,MessageSvc,RoleSvc,UpdateConfigSvc,DeleteConfigSvc) {
	console.log("Config param ctrl Start");
	
	$rootScope.whenOnhome=false;
	$scope.submitFlag=false;
	var attuid = $cookieStore.get("attuid").toLowerCase();
	
	
	ConfigSvc.getConfig(function (cfg) {
	var webSRCPath = ConfigSvc.getAbsPath();
	var GetSupporturlForRef = webSRCPath + cfg.fetchConfigProperties;
	var param=new FormData();
	var url=GetSupporturlForRef;			 	 	
 	console.log("url to connect to service: "+url); 		  			
		$http.get(url, param, {
			transformRequest: angular.identity,
			headers: {'Content-Type': undefined}
		})
		.then( function(response) { 						
			 $scope.espProperty = response.data;
		});	 			
	});
	 
	 
	$scope.updateConfigRecords = function(data){		
		$scope.functionType="update";
    	sessionStorage.updateCofigData = JSON.stringify(data);
    	$scope.updateConfigPopUp=JSON.parse(sessionStorage.updateCofigData);	    
		$('#update-detail').modal('show');	                 
	};
	
	$scope.closeWindow = function (){	    	
    	$('#update-detail').modal('hide');
	};
	
	$scope.resetUpdateConfig = function(){
		$scope.updateConfigPopUp=JSON.parse(sessionStorage.updateCofigData);
	};
	
	
	$scope.updateConfigRecord = function(){
		$scope.submitFlag=true;		
		if($scope.updateConfigPopUp.value == null || $scope.updateConfigPopUp.value == undefined || $scope.updateConfigPopUp.value == ""){
			$scope.updateErrorMsg=true;
		} else{
			if(!$rootScope.notURL){	
				$('#update-cnfrm').modal('show');
				$("#update-cnfrm").find("#okUpdate").on("click", function () {
					UpdateConfigSvc.updateConfigRecord($scope.updateConfigPopUp, attuid);
				});
				$("#update-cnfrm").find("#cancelUpdate").on("click", function () {
					$('#update-cnfrm').modal('hide');
		        });
			}
	   }		
	};
	
	
	$scope.deleteRecord = function (configKey)  
	{    	
		$scope.functionType="delete";
		console.log('inside delete function record id to be deleted : '+configKey);
		$('#update-cnfrm').modal('show');
		
		$("#update-cnfrm").find("#okUpdate").on("click", function () {			
			DeleteConfigSvc.deleteConfigRecord(attuid,configKey);        	
		});
		$("#update-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#update-cnfrm').modal('hide');
        });
	};
	
	console.log("Config param ctrl End");
});


app.controller('addConfigParamCtrl',
		function configParamCtrl($scope, $http, $rootScope, $cookieStore, GlobalLogonSvc,ConfigSvc,DropDownSvc,$location,MessageSvc,RoleSvc,AddConfigSvc) {
	console.log("Config param ctrl Start");
		$rootScope.whenOnhome=false;
		$scope.add = {};	
		$scope.addValue = function (){				
			$scope.addFlag = true;				
			if($scope.addConfigPopUp.key == "" || $scope.addConfigPopUp.key == null || $scope.addConfigPopUp.key == undefined ||
					$scope.addConfigPopUp.value == "" || $scope.addConfigPopUp.value == null || $scope.addConfigPopUp.value == undefined){
				$scope.addFlag = true;				
			} else {
				AddConfigSvc.addConfigDetails($scope.addConfigPopUp.key,$scope.addConfigPopUp.value, $scope.addConfigPopUp.description); 
			}			
		};
		$scope.addConfigResetBtn = function (){
			$scope.addConfigPopUp.key ="";
			$scope.addConfigPopUp.value ="";
			$scope.addConfigPopUp.description ="";
		};
	console.log("Config param ctrl End");
});


app.controller('espEntryCtrl',
		function espEntryCtrl($scope, $http, $rootScope, $cookieStore,$compile, GlobalLogonSvc,ConfigSvc,DropDownSvc,$location,MessageSvc,RoleSvc,GetEspEntrySvc,AddEntrySvc) {
		console.log("espEntry ctrl Start");
		
		$rootScope.whenOnhome=false;
		userRoleTimer();
		function userRoleTimer(){
		     
		               setTimeout(function(){
		                var actionList = $cookieStore.get("roles"); 
		                
		                  if(actionList === undefined)
		                  {
		                     	   userRoleTimer();
		                  }
		                  else{
		$scope.$apply(function () {
		 
			if(actionList.indexOf("CFGUPD") !== -1)
			 {
			 $rootScope.updateEspShow = true; 
			 $rootScope.isSuperAdmin = true;
			 console.log("user is a Super Admin");	
			 }	
			else if(actionList.indexOf("SRCHESPEDT") !== -1)
				{
				$rootScope.updateEspShow = true; 
				console.log("user is a an Admin with role :SRCHESPEDT ");	
				}
			else
				{
				console.log("no admin/super admin roles found, role found : SRCHESPVW");	
				}
			console.log("inside DropDownSvc CNTRY_CD");

			DropDownSvc.dropDownValues("CNTRY_CD");
			
		    
		       });
		           		  
		                  }

		},800);
		 }
		
		$scope.EntrySearch = {};

		$rootScope.$on('dropDownDataObject', function (events,args) {
			entryCountryDD=[];
			countForCountry = 0;
		$rootScope.valuesData = DropDownSvc.dropDownData;
			for(var i in $rootScope.valuesData){
				
			if($rootScope.valuesData[i].key == "CNTRY_CD"){
				entryCountryDD[countForCountry]=$rootScope.valuesData[i].values;
					countForCountry = countForCountry + 1;
				}
			}
			
			$scope.entryCountryoptions = entryCountryDD;

		});

		$scope.espEntryResetBtn = function()
		{
			$scope.EntrySearch = {};
			}

		$scope.submitFlagEntry = false;
		
		$scope.AllEspEntry = function(){
			console.log("in allespentry function: ");
			$scope.submitFlagEntry = true;
			console.log("value of flag: "+$scope.submitFlagEntry);
			
			
		if($scope.EntrySearch.ESPName === null || $scope.EntrySearch.ESPName === '' || $scope.EntrySearch.ESPName === undefined )
			{
			  $scope.EntrySearch.ESPName = '';
			}
		  if($scope.EntrySearch.ESPFullName === null || $scope.EntrySearch.ESPFullName === '' || $scope.EntrySearch.ESPFullName === undefined )
		  {
		  $scope.EntrySearch.ESPFullName = '';
		  }
		  if($scope.EntrySearch.COUNTRY === null || $scope.EntrySearch.COUNTRY === '' || $scope.EntrySearch.COUNTRY === undefined )
		  {
		  $scope.EntrySearch.COUNTRY = '';
		  }
			 
			GetEspEntrySvc.getEntryDetails($scope.EntrySearch.ESPName,$scope.EntrySearch.ESPFullName,$scope.EntrySearch.COUNTRY);
			
			  
			 $rootScope.$on('entryDetailsDataObject', function (events,args) {
				 console.log("received response from service"+GetEspEntrySvc.entryDetailsData);
				// console.log(GetEspEntrySvc.entryDetailsData);
				 $scope.JsonEntry = GetEspEntrySvc.entryDetailsData;
				  }
			  ) 
			 // console.log("AFTER ADD+++++++++++++");
			
		}
	
		
		var count = 0;
		$scope.addedRowsData=[];
		$scope.addEspEntry = function(){
			console.log('current val f count '+count);
			//$scope.checkedBoxVal = [];
			console.log("in addEspEntry function: ++++");
			$scope.submitFlagEntry = true;
			
			
			//var table=document.getElementById("entryTable");
			
		            var markup = '<tr><td style="width: 6em; padding: 9px;"><input style="width: 3em;padding: 3px; margin-left: 12px;" type="checkbox" ng-model="addedRowsData['+count+'].checkbox"></td>'+
					'<td style="width: 8em; padding: 4px;"><input class="form-control" ng-model="addedRowsData['+count+'].espName"></td>'+
					'<td style="width: 8em; padding: 4px;"><input class="form-control" ng-model="addedRowsData['+count+'].espFullName"></td>'+
					'<td style="width: 8em; padding: 4px;"><input class="form-control" ng-model="addedRowsData['+count+'].hqCountryCode"></td></tr>';
		            
		           // $(table).find('tbody').append(markup);    
		            angular.element(document.getElementById('entryTable')).append($compile(markup)($scope));
			count++;
			
			console.log('value of addedRows data : '+JSON.stringify($scope.addedRowsData));
				}
		
		
		
		$scope.espEntryAddbtn = function(){
			$scope.finalAddedData = [];
			console.log("value1 of addedRowsData: "+JSON.stringify($scope.addedRowsData));
			console.log("in espEntryAddbtn function: ++++");
			var rowData = $scope.addedRowsData;
			
			var table=document.getElementById("entryTable");
	
		 for(var i = 0; i < rowData.length ; i++){
			// console.log("in for loop"+(rowData[i]['checkbox']));
			 if(rowData[i] != null){
			 if((rowData[i]['checkbox']) === true)
			 {
				 delete rowData[i]['checkbox'];
				 $scope.finalAddedData.push(rowData[i]);
			
			 }
			 }
		 	}
		 console.log("value of final added data: "+JSON.stringify($scope.finalAddedData));
		 
		 AddEntrySvc.addEntryDetails($scope.finalAddedData);
		 
		/* $rootScope.$on('addEntryDetailsDataObject', function (events,args) {
			 console.log("received response from service"+AddEntrySvc.addEntryDetailsData);
			// console.log(GetEspEntrySvc.entryDetailsData);
			 $scope.JsonAddEntry = AddEntrySvc.addEntryDetailsData;
			  }
		  ) */
			
		}
		
		
		$scope.deleteEntry = function(){
			console.log("in deleteEntry function: ++++");
			console.log('inside delete function to be deleted :');
			$('#update-cnfrm').modal('show');
			
			$("#update-cnfrm").find("#okUpdate").on("click", function () {			
				//DeleteConfigSvc.deleteConfigRecord(attuid,configKey);  
				$('#update-cnfrm').modal('hide');
				var table=document.getElementById("entryTable");
				$(table).find('tbody input[type=checkbox]').each(function(){
	            	if($(this).is(":checked"))
	            	{
	                    $(this).parents('tr').remove();
	                }
				});	
				
			});
			
			
			$("#update-cnfrm").find("#cancelUpdate").on("click", function () {
				$('#update-cnfrm').modal('hide');
	        });
		}
	
});
//start of addUpdateCatalog ctrl 
app.controller('addUpdateCatalogCtrl', 
		function addUpdateCatalogCtrl($scope ,$http, $log,$compile, $rootScope,$cookieStore, $window, $location,$timeout,$scope, MessageSvc,DropDownSvc,myService,GlobalLogonSvc,GetCatalogValidValSvc,
				UpdtCatalogValidValSvc,DeleteCatalogValidValSvc,AddCatalogDataSvc){ 
	console.log('Inside add update catalog ctrl'); 
 
 
	$scope.updateSupportInput={}; 
	$rootScope.whenOnhome=false; 
	$scope.submitFlag=false; 
	$scope.espCatalog={};
	$scope.addCatalogData={};
	userRoleTimer(); 
	//Start of user role timer 
  function userRoleTimer(){ 
 
                 setTimeout(function(){ 
                  var actionList = $cookieStore.get("roles"); 
 
                    if(actionList === undefined) 
                    { 
                       	   userRoleTimer(); 
                    } 
                    else{ 
                  	  $scope.$apply(function () { 
 
                  		  if(actionList.indexOf("SUPUPDT") !== -1) 
                  		  	{ 
                  		  	$rootScope.updateSupportShow = true; 
                  		  	console.log("action role for addUpdateCatalogCtrl: SUPUPDT "); 
                  		  	DropDownSvc.dropDownValues("DATA_TYPE"); 
                  		    //GetCatalogValidValSvc.getCatalogValues("DATA_TYPE_PAGE_LOAD");
                  			 
                  		  	} 
                  		  else 
                  		  	{ 
                  		  	$location.path('/home/'); 
                  		  	console.log("no role present in addUpdateCatalogCtrl"); 
                  		  	} 
 
                  		             }); 
 
                    } 
 
},800); 
   } 
  //end of user role timer 
  
  var attuid = $cookieStore.get("attuid").toLowerCase(); 
  console.log('value of attuid1 : '+attuid);
  $scope.catalogDataTypeDD=[]; 
//on function to get DD value 
  $rootScope.$on('dropDownDataObject', function (events,args) { 
 
  	$scope.valuesDataCatalog = DropDownSvc.dropDownData; 
  	//console.log('complete value of dd '+JSON.stringify($scope.valuesDataCatalog));
  		for(var i in $scope.valuesDataCatalog){ 
  			//console.log('values '+JSON.stringify($scope.valuesDataCatalog[i]));
  			if($scope.valuesDataCatalog[i].key == attuid){ 
  				//$scope.catalogDataTypeDD[i] = $scope.valuesDataCatalog[i].values;
  				$scope.catalogDataTypeDD.push($scope.valuesDataCatalog[i].values);
  			} 
  		} 
  		console.log('value112 of request type dd '+JSON.stringify($scope.catalogDataTypeDD)); 
  }); 
  //end of on function to populate DD 
  
  //function to call get valid values service 
  $scope.dataTypeChange= function(){
	  $scope.elementsDD=[];
	  $scope.validValueData=[];
	  $scope.espCatalog.elementType=null;
	  //console.log('value of data type1 selected1 : '+$scope.espCatalog.dataType);
	  GetCatalogValidValSvc.getCatalogValues($scope.espCatalog.dataType);
	  
  }
  
 $scope.espCatalogResponse={};
  
  $rootScope.$on('espCatalogDataObject', function (events,args) {
  	$scope.espCatalogResponse = GetCatalogValidValSvc.espCatalogValidVals.responseObj;
  	sessionStorage.espCatalogResponse=JSON.stringify($scope.espCatalogResponse);
  	//console.log('value in2 ctrl '+JSON.stringify($scope.espCatalogResponse));
  	
  	 for(var i=0; i<$scope.espCatalogResponse.length;i++){
  		 if($scope.espCatalogResponse[i].ddVldVal.split(':').length ==2){
  		$scope.elementsDD.push($scope.espCatalogResponse[i].ddVldVal.split(':')[0]);
  		//console.log('inb for loop : '+$scope.espCatalogResponse[i].ddVldVal.split(':')[0]);
  		 }
  		 
  	  }
  	console.log('value of ement dd '+JSON.stringify($scope.elementsDD));
  });
  
  $scope.elementTypeChange= function(){
	  $scope.validValueData=[];
	  $scope.espCatalogResponse=JSON.parse(sessionStorage.espCatalogResponse);
	  //console.log('lenght1 '+$scope.espCatalogResponse.length);
	  //console.log('value of data element selected1 : '+$scope.espCatalog.elementType);
	  //console.log('xxxxxxxxxxxx '+JSON.stringify($scope.espCatalogResponse));
	  for(var i=0; i<$scope.espCatalogResponse.length;i++){
		  console.log('value of elemet : '+$scope.espCatalogResponse[i].ddVldVal.split(':')[0]);
	  		if($scope.espCatalogResponse[i].ddVldVal.split(':')[0] === $scope.espCatalog.elementType){
	  			console.log('i val '+i);
	  			var count=0;
	  			$scope.validValueData.push($scope.espCatalogResponse[i]);
	  			$scope.validValueData[count].ddVldVal=$scope.espCatalogResponse[i].ddVldVal.split(':')[1];
	  			count++;
	  		}
	  			
	  	  }
	  //console.log('valid value data : '+JSON.stringify($scope.validValueData));
	  
  }
  
  $scope.editValues= function(item){
	  console.log('inside312 edit');
	  //$scope.catalogVals=[];
	  console.log('value of data1 pssed : '+JSON.stringify(item)+' and id '+item.id);
	  $scope.espCatalog.id=item.id;
	  $scope.espCatalog.editValues=item.ddVldVal.split(',');
	  sessionStorage.catalogVldVals=item.ddVldVal.split(',');
	  angular.element(document.getElementById('catalog')).empty();
	  for(var i=0;i<$scope.espCatalog.editValues.length;i++){
		  
		  var input = '<input class="form-control" type="text" style="margin-left: 88px;width: 19em;margin-top: 10px;" ng-model="espCatalog.editValues['+i+']">';
		  //$compile(input)($scope);
		 
		  angular.element(document.getElementById('catalog')).append($compile(input)($scope));
		  
	  }
	  
	  $('#catalog-values').modal('show');
	  
  }
  
  $scope.addValidValue = function (){
	  	
	  var i=$scope.espCatalog.editValues.length;
	  console.log('length of valdi values '+$scope.espCatalog.editValues.length);
	  var input = '<input class="form-control" id="'+i+'" type="text" style="margin-left: 88px;width: 19em;margin-top: 10px;" ng-model="espCatalog.editValues['+i+']">';
	  //$compile(input)($scope);
	 
	  angular.element(document.getElementById('catalog')).append($compile(input)($scope));
		
  }
  
 /* $scope.removeValidValue = function (){
	  	
	  var i=$scope.espCatalog.editValues.length-1;
	  console.log('length -1 of valdi values '+$scope.espCatalog.editValues.length);
	  //var input = '<input class="form-control" type="text" style="margin-left: 88px;width: 19em;margin-top: 10px;" ng-model="espCatalog.editValues['+i+']">';
	  //$compile(input)($scope);
	 
	 // angular.element(document.getElementById('catalog')).append($compile(input)($scope));
	  angular.element(document.getElementById(i)).empty();
  }*/
	  
  $scope.closeWindow = function (){
  	
  	$('#catalog-values').modal('hide');
	}
  
  $scope.resetCatalogValues = function(item){
	 // console.log('sasdasdas1 '+sessionStorage.catalogVldVals.length);
	 
	  $scope.espCatalog.editValues=sessionStorage.catalogVldVals.split(',');
	  
	}
  $scope.operation=null;
  $scope.updateCatalogValue=function(){
	  $scope.operation='update';
	  console.log('inside uodt');
	  $('#catalog-cnfrm').modal('show');
		
		$("#catalog-cnfrm").find("#okUpdate").on("click", function () {
			UpdtCatalogValidValSvc.updateCatalogValues($scope.espCatalog);
		});
		$("#catalog-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#catalog-cnfrm').modal('hide');
      });
	  
  }
  
  $scope.addCatalogData=function(){
	  $('#add-catalog').modal('show');
  }
  
  $scope.closeAddWindow=function(){
	  $('#add-catalog').modal('hide');
  }
  
  $scope.resetAddCatalog=function(){
	  $scope.addCatalogData={};
  }
  
  $scope.addCatalogDataValue=function(){
	  $scope.operation='add catalog data';
	  $scope.submitFlag=true;
	  
	  if($scope.addCatalogData.dataType === null || $scope.addCatalogData.dataType === undefined || $scope.addCatalogData.dataType === ''){
		  $scope.addErrorMsg=true;  
	  }else{
		
		  $('#catalog-cnfrm').modal('show');
		
		  $("#catalog-cnfrm").find("#okUpdate").on("click", function () {
			AddCatalogDataSvc.addCatalogData($scope.addCatalogData);
		  });
		  $("#catalog-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#catalog-cnfrm').modal('hide');
		  });
		  
	  }
  }
  
  $scope.deleteCatalogRecord = function(id){
	  $scope.operation='delete';
	  console.log('id to be deleted '+id);
	  $('#catalog-cnfrm').modal('show');
		
		$("#catalog-cnfrm").find("#okUpdate").on("click", function () {
			DeleteCatalogValidValSvc.deleteCatalogValues(id);
		});
		$("#catalog-cnfrm").find("#cancelUpdate").on("click", function () {
			$('#catalog-cnfrm').modal('hide');
    });
	  
  }
 
 
} 
);