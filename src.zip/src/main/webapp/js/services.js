'use strict';

/* Services */
angular.module('pedespgui.services', ['ngCookies'])


.factory('ConfigSvc', ['$http', '$location', '$rootScope', '$log', function ($http, $location, $rootScope, $log) {

	function ConfigSvc() {

		// $log.info("Config Service");
		var self = this;

		this.configNotifiers = [];

		this.getAbsPath = function () {
			$log.info("self.config.webSvcServer=" + self.config.webSvcServer);
			//code to check server is production/development

			$rootScope.toolsEnv = self.config.BuildDetect;
			//End of code to check server is production/development

			//code to check server is localhost or devlopment/production
			if (self.config.webSvcServer === "dev" ||
					self.config.webSvcServer === "uat" ||
					self.config.webSvcServer === "test") {
				//$log.info("inside dev");
				//get server url to append webservice name
				var absURL = $location.absUrl(); //get full url
				var URLStr = $location.url(); // get the path of url
				var serviceURL = self.config.webSvcServerLink;//replace the path, root folder name and rootpage name with blank

			}
			else {
				//if localhost then take the url of webservice from config file
				//$log.info("inside local");
				var serviceURL = self.config.webSvcServerLink;
			}
			return serviceURL;
		};
		//var test=getAbsPath();
		this.getConfig = function (notifyOnConfig) {

			if (this.config)
				notifyOnConfig(this.config);
			else {
				this.configNotifiers.push(notifyOnConfig);
			}

		};

		$http.get('js/config.json').success(function (cfg) {

			self.config = cfg;
			while (self.configNotifiers.length > 0) {

				self.configNotifiers.shift()(cfg);
			}
//			$rootScope.$broadcast('ConfigLoaded');
		});
	}
	;

	return new ConfigSvc();
}])

.factory('GlobalLogonSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$location', '$routeParams', 'RoleSvc',
                            function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $location, $routeParams, RoleSvc) {

	function GlobalLogonSvc() {
		var self = this;
		//$log.info("GlobalLogonSvc init...");
		ConfigSvc.getConfig(function (cfg) {
			self.globalLogonUrl = cfg.GlobalLogonUrl;
			self.glAppIndexUrl = encodeURIComponent($location.absUrl());//cfg.GLAppIndexUrl;
			//$log.info("Redirect to global logon: " + self.glAppIndexUrl);
			self.GlobalLogonDisable = cfg.GlobalLogonDisable;

			//Code added on 14th Oct to check attuid of person from config as the uniqque issue of 
			//Cingular Id issue of the German. Get the value of multiple ids from config file
			self.CinattuidConfig = cfg.CinattuidConfig;

			self.redirectGlobalLogon();
		});
		var unexpectedErrorHandler = function (data, status, headers, config) {
			// $rootScope.$broadcast('BusyEnd');
			//$log.info('Query returned error: status=' + status + '; resp=' + data);
			if ($routeParams.Common_Id !== undefined) {
				$rootScope.commonidflag = true;
				MessageSvc.displayErrorMessage('Please close all browser windows & relaunch ESP');
			}
			else {
				MessageSvc.displayErrorMessage('Unexpected error while User Authentication. ' +
				'Please try again later.');
			}

		};

		this.redirectGlobalLogon = function () {
			// $log.info("Authenticating...");
			// $rootScope.$broadcast('BusyStart');
			$rootScope.objOffsetVersion;
			if ((navigator.userAgent.indexOf("Trident")) !== -1 || (navigator.userAgent.indexOf("MSEI")) !== -1) {
				$rootScope.objbrowserName = "Internet Explorer";
			}



			var ua = navigator.userAgent;
			var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
			if (re.exec(ua) !== null)
				$rootScope.objOffsetVersion = parseFloat(RegExp.$1);
			// console.log("value of objOffsetVersion" + $rootScope.objOffsetVersion);
			var browserdetectflag = '';
			if ($rootScope.objbrowserName === "Internet Explorer") {
				if ($rootScope.objOffsetVersion < 11) {
					browserdetectflag = true;
				}
				else {
					browserdetectflag = false;
				}
			} else {
				browserdetectflag = false;
			}
			//console.log("value of browserdetectflag" + browserdetectflag);

			$cookieStore.put("browserdetectflag", browserdetectflag);
			var attuid = "";
			var userRole = "";

			// Initialize cookies
			$cookieStore.put("attuid", attuid);
			$cookieStore.put("userRole", userRole);

			//var redirected = false;
			if (browserdetectflag === false) {
				if (self.GlobalLogonDisable === 'Y' || self.GlobalLogonDisable === 'y')
				{
					attuid = "pa291p";
					$cookieStore.put("userName", "User");
					$rootScope.userName =  $cookieStore.get("userName"); 
					//RoleSvc.getRoles(attuid);
					$cookieStore.put("attuid", attuid);
					//code added to call rolesvc for users without global logon
				}
				else
				{

					var attESHr = document.cookie.indexOf("attESHr");
					if (attESHr >= 0) {
						var attuidGlobal = "";
						var name = 'attESHr';
						var nameEQ = name + "=";
						var ca = document.cookie.split(';');
						//$log.info('ca.length =' + ca.length);
						for (var i = 0; i < ca.length; i++) {
							var c = ca[i];
							while (c.charAt(0) === ' ')
								c = c.substring(1, c.length);
							if (c.indexOf(nameEQ) === 0) {
								attuidGlobal = c.substring(nameEQ.length, c.length);
								break;
							}
						}
						// $log.info('attuidGlobal' + attuidGlobal);
						if (attuidGlobal !== "") {
							$log.info('attuidGlobal' + attuidGlobal);
							var result = attuidGlobal.split('%7c');
							result[0] = result[0].replace("+", " ");
							result[1] = result[1].replace("+", " ");
							var userName = result[0] + " " + result[1];
							var userPhone = result[3];
							//userName = "";
							//$log.info('userName--' + userName);
							//$log.info('Phone-' + userPhone);
							/**First name and last name
							 * For some user who don't have last name, their last name in cookie will be first name first name*/
							//so for these cases showing only first name
							$log.info('first name-' + result[0]);
							$log.info('last name-' + result[1]);


							if (result[0] === result[1]) {
								userName = result[0];
							}



							//$log.info('userName before DecodeURI' + userName);
							userName = decodeURI(userName);
							userName = userName.replace("+", " ");
							userName = userName.replace("-", " ");
							userName = userName.replace("_", " ");
							userName = userName.replace("%", " ");
							userName = userName.replace("#", " ");
							//$log.info('userName after DecodeURI' + userName);


							var attuidRes = result[7].split('%2c');
							//$log.info('attuidRes' + attuidRes);
							attuid = attuidRes[0];

							/*  START Code added on 14th Oct to check attuid of person from config as the uniqque issue of 
							 *Cingular Id issue of the German*/
							var CinattuidConfig = this.CinattuidConfig;
							var CinattuidconfigFlag = false;
							for (var i = 0; i < CinattuidConfig.length; i++) {
								if (attuid === CinattuidConfig[i].split(":")[0]) {
									$cookieStore.put("attuid", CinattuidConfig[i].split(":")[1]);
									RoleSvc.getRoles($cookieStore.get("attuid")); 
									CinattuidconfigFlag = true;
									$cookieStore.put("userName", userName);
									$rootScope.userName =  $cookieStore.get("userName"); 
									//code to show username for the german client
									// console.log("inside config cinattuid");
								}
							}
							/* END Code added on 14th Oct to check attuid of person from config as the uniqque issue of 
							 *Cingular Id issue of the German*/
							/*START ATTUID and cingular ID issue fix on 26-02-2015 
							 * for cingular/attu id not matching from config*/
							var cinArr = result[2].split('%40');
							if (CinattuidconfigFlag === false) {
								if (cinArr[1].match("att")) {

									var cinAttuid = cinArr[0];
									cinAttuid = cinAttuid.toUpperCase();
									$cookieStore.put("cinAttuid", cinAttuid);
									//$log.info('cingular attuid-' + cinAttuid);
									$cookieStore.put("attuid", cinAttuid);
									attuid = cinAttuid;

									//code added by pa291p to fix the missing username on the screen
									$cookieStore.put("userName", userName);
									$rootScope.userName =  $cookieStore.get("userName"); 

									RoleSvc.getRoles(attuid);
									//calling role service with attuid
									//$cookieStore.put("attuid", cinAttuid);
								}
								else {
									// console.log("else in db code" + attuid);
									attuid = attuid.toUpperCase();
									//$log.info('attuid upper case: ' + attuid);
									$cookieStore.put("attuid", attuid);
									$cookieStore.put("userName", userName);
									$rootScope.userName =  $cookieStore.get("userName"); 
									$cookieStore.put("cinAttuid", attuid);
									RoleSvc.getRoles(attuid);
								}
							}

							//code to format the phone number in XXX-XXX-XXXX and store in cookie
							if (userPhone !== "") {
								//decode the phone number and replace non digit with blank
								userPhone = decodeURI(userPhone);
								userPhone = userPhone.replace(/\D/g, "");
								if (userPhone.length >= 10) {
									userPhone = userPhone.substring(0, 10);
								} else {
									userPhone = "0000000000";
								}
								// $log.info('userPhone = ' + userPhone);

								var strPhone = userPhone.replace(/(.{3})/g, "$1-");
								var userPhone = strPhone.slice(0, -2) + strPhone.slice(-1);
								$cookieStore.put("userPhone", userPhone);

							} else {
								$cookieStore.put("userPhone", "000-000-0000");
								//$log.info('userPhone = ' + userPhone);
							}



							// $rootScope.$broadcast('BusyEnd');
						} else {
							var url = this.globalLogonUrl + "/?retUrl=" + this.glAppIndexUrl;
							//$log.info("Redirecting to global logon: " + url);
							//    $rootScope.$broadcast('BusyEnd');
							window.location = url;
						}
					} else {

						var url = this.globalLogonUrl + "/?retUrl=" + this.glAppIndexUrl;   
						//$log.info("Redirecting to global logon: " + url);
						//   $rootScope.$broadcast('BusyEnd');
						window.location = url;
					}

				}

			}
		};


	}
	return new GlobalLogonSvc();
}])

.factory('DropDownSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', '$sce', '$routeParams',
                         function ($rootScope, $http, $log, $cookieStore, ConfigSvc, $sce, $routeParams) {
	function DropDownSvc() {
		var self = this;
		this.dropDownData = {};               	
		this.dropDownValues=function(value){
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				$log.info("webSRCPath"+webSRCPath);
				self.GetDropDownUrl = webSRCPath + cfg.dropDownValues;

				var param=new FormData();
				var url=self.GetDropDownUrl;

				param.append('Type',value);

				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					var data=response.data;
					self.dropDownData = data;
					$rootScope.$broadcast('dropDownDataObject',data);        				

						});
			});
		};
	}
	return new DropDownSvc();
}])        

.factory('MessageSvc', ['$rootScope','$log', function ($rootScope, $log) {
	function MessageSvc() {
		this.infoMessage = '';
		this.warnMessage = '';
		this.errorMessage = '';
		this.errorMessageAuth ='';
		this.displayInfoMessage = function (msg) {
			$rootScope.infoMessage=msg;                       
			$rootScope.$broadcast('NewInfoMessage');
		};

		this.displayWarnMessage = function (msg) {
			this.warnMessage = msg;
			$rootScope.$broadcast('NewWarnMessage');
		};

		this.displayErrorMessage = function (msg) {
			$rootScope.errorMessage=msg;
			$rootScope.$broadcast('NewErrorMessage');
		};

//		START New error message added for not authorized users on 20th Oct as on click of ok it needs to go to home page
		this.displayErrorMessageAuth = function (msg) {
			this.errorMessageAuth = msg;
			$rootScope.$broadcast('NewErrorMessageAuth');
		};
		//END New error message added for not authorized users on 20th Oct as on click of ok it needs to go to home page
		this.displayRetryInfoMessage = function (msg) {
			this.infoRetryMessage = msg;
			$rootScope.$broadcast('NewRetryInfoMessage');
		};

		this.displayErrorWithActionMessage = function (msg) {
			this.warnMessage = msg;
			$rootScope.$broadcast('NewErrorWithActionMessage');
		};

	}
	return new MessageSvc();
}])


.factory('uploadSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$routeParams',
                       function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc,  $routeParams) {

	function uploadSvc()
	{
		var self = this;

		this.addUploadEsp = function(fileHandle)
		{   
			var fd = new FormData();
			fd.append('apiName','ESP GUI File Upload');
			fd.append('userid',$cookieStore.get("attuid"));
			fd.append('file', fileHandle);

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetFileUploadUrl = cfg.ESPfileUploadSrvc;
			});
			$log.info("addUploadEsp url:"+self.GetFileUploadUrl);
			var fileUploadUrl=self.GetFileUploadUrl;
			$rootScope.$broadcast('BusyStart');
			$http.post(fileUploadUrl, fd, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			})
			.then( function(response) 
					{
				var data=response.data;
				$rootScope.$broadcast('BusyEnd');
				if(data == null ||
						data.uploadSts == null || data.uploadSts == 'null' || 	
						(data.uploadSts != null && data.uploadSts==1))
				{
					//$scope.UploadFileFlagError=true;	
					// $scope.UploadFileFlagSuccess=false;
					MessageSvc.displayErrorMessage ("Error uploading the file, please try again.");
					$rootScope.ushFlag = true;// flag to show ush ticket fata in the modal window 
					//console.log("Error while uploading the file, Please try again. Contact Administrator if this issue persists.");
				}
				else
				{
					//$scope.UploadFileFlagError=false;	
					//  $scope.UploadFileFlagSuccess=true;	
					MessageSvc.displayInfoMessage ("File Uploaded Successfully, Data is processed periodically and you would receive an email after the Upload process is complete");
				}
					});


		}

	} return new uploadSvc();
}])

.factory('RoleSvc', ['$rootScope', '$http', '$log', '$cookieStore','$location', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                     function ($rootScope, $http, $log, $cookieStore,$location, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function RoleSvc() {

		var self = this;
		self.RoleSvcData = {};

		var unexpectedErrorHandler = function (data, status, headers, config) {
			$rootScope.$broadcast('BusyEnd');
			//$log.info('Query returned error: status=' + status + '; resp=' + data);
		};

		this.getRoles = function (userid)
		{
			//the function is once called with attuid and the other time with cingular id

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.RoleSvcUrl = webSRCPath + cfg.userRoleSvc;
			});

			var roled = $cookieStore.get("roles");

			if(roled == undefined)
			{

				$log.info("no roles exists in the cookies, calling servcie");
				var RoleSvcUrl = this.RoleSvcUrl;
				var attuid = $cookieStore.get("attuid").toLowerCase();
                            $cookieStore.put("attuid",attuid);
				//call webservice with attuid
				var url = RoleSvcUrl + "?userid=" + attuid ;
                           // var url = RoleSvcUrl ;
                            var param=new FormData();
                            param.append('userid',attuid);
                            param.append("cookie",$cookieStore);
                            console.log("param-"+param);
                            console.log("RoleSvcUrl:"+RoleSvcUrl);
                            	$cookieStore.put("a","a");
                            	var attESHr = document.cookie.indexOf("attESHr");
				$rootScope.$broadcast('BusyStart');
                           //$http.get(url,)
                            
                            $http({
                            	  method: 'GET',
                            	  url: url//,
                            	 }).then(function successCallback(response) {
                            	  // do stuff
                            		console.log("succ");
                            		console.log(response.data);
                            		var data=response.data;
					$rootScope.$broadcast('BusyEnd');
					self.RoleSvcData = data;
					$log.info(self.RoleSvcData );
					$rootScope.$broadcast('RoleSvcResp');
                            	  }, function errorCallback(response) {
                            	  // oh noes!
                            		  console.log("errr");
				});
			}

			else
			{
				$log.info("roles already exist, do not call servcie again");
				var actionList =  $cookieStore.get("roles");
				if (actionList.indexOf("ADDESP") !== -1)
				{
					$rootScope.updateEspShow = true; 
				}
				$rootScope.flashMsg =  $cookieStore.get("flashMsg");
			}
		}

		$rootScope.$on('RoleSvcResp', function (events,args) {
			//var data = RoleSvc.RoleSvcData.roles;
                    var actionList = self.RoleSvcData.responseObj.actionList;
                    console.log("actionList-"+actionList);
                    if(self.RoleSvcData.value == 'FAIL')
			{
				$log.info("user is not a registered user. redirect to mylogins page")
				$location.path('/userNotRegistered/'); 
			}
			else
			{
				$log.info("valid user, redirect with roles values: "+actionList);

				if (actionList.indexOf("ADDESP") !== -1)
				{
					$rootScope.updateEspShow = true; 
				}
				else
				{
					//console.log("user has RO role on  Add/Update ESP");
				}

				$cookieStore.put("roles",actionList);

			}
               	 $cookieStore.put("flashMsg",self.RoleSvcData.responseObj.flash);
			$rootScope.flashMsg = $cookieStore.get("flashMsg");
		});

		$rootScope.$on('BusyStart', function(){
			$("#busy-spinner").css("display", "block"); 
		});

		$rootScope.$on('BusyEnd', function(){
			$("#busy-spinner").css("display", "none"); 

		});

	}  return new RoleSvc();
}])


.factory('AllEspSearchSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams', 
                             function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function AllEspSearchSvc() {

		var self = this;
		this.countryData = {};
		this.networkData = {};
		this.prodDetData = {};
		this.searchBySearchCriteria=function(searchCriteria,ATTProductID,countryCode,ituCarrierCode,
				stateProvence,popClli,interConnectType,evcSpeed,Lat,Long,Product_Type,CMTU,ATT_Product_Status){
			var param=new FormData();
			var url='';
			if(searchCriteria=='Country'){
				ConfigSvc.getConfig(function (cfg) {
					var webSRCPath = ConfigSvc.getAbsPath();
					self.GetCountryApiUrl = webSRCPath + cfg.searchByCountry;
				});
				
				url=self.GetCountryApiUrl;
				param.append('countryCode',countryCode);
				param.append('ituCarrierCode',ituCarrierCode);
				param.append('stateProvence',stateProvence);
			}

			else  if(searchCriteria=='Product'){
				ConfigSvc.getConfig(function (cfg) {
					var webSRCPath = ConfigSvc.getAbsPath();
					self.GetProdApiUrl = webSRCPath + cfg.searchByProduct;
				});
				url=self.GetProdApiUrl;

				param.append('latitude',Lat);
	param.append('longitude',Long);
				param.append('agnNode',ituCarrierCode);
				param.append('countryCode',countryCode);
				param.append('customerSpeed',evcSpeed);
				param.append('productType',Product_Type);
				param.append('cmtu',CMTU);
				param.append('attProductStatus',ATT_Product_Status);

			}

			else  if(searchCriteria=='Network'){
				ConfigSvc.getConfig(function (cfg) {
					var webSRCPath = ConfigSvc.getAbsPath();
					self.GetNetworkApiUrl = webSRCPath + cfg.searchByNetwork;
				});

				url=self.GetNetworkApiUrl;

				param.append('countryCode',countryCode);
				param.append('ituCarrierCode',ituCarrierCode);
				param.append('popClli',popClli);
				param.append('interConnectType',interConnectType);
				param.append('evcSpeed',evcSpeed);
			}

			else  if(searchCriteria=='ProductDetails'){
				ConfigSvc.getConfig(function (cfg) {
					var webSRCPath = ConfigSvc.getAbsPath();
					self.GetProdDetApiUrl = webSRCPath + cfg.searchByProductDetail;
				});
				url=self.GetProdDetApiUrl;

				param.append('attProductID',ATTProductID);
			}
			$rootScope.$broadcast('BusyStart');
			$http.post(url, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			})
			.then( function(response) 
					{$rootScope.$broadcast('BusyEnd');
					var data=response.data;
					self.Data = data.responseObj;
					console.log('respinse for country : '+JSON.stringify(response));
					/*console.log("length of the object: "+self.Data.length);*/

					if(data.key === 2)
					{
						//alert("no data found");
						MessageSvc.displayInfoMessage("No data found.Please perform another search.");
//						$('#info-msg').modal('show');
					}
					else if((data.key== null || data.key=== 100) && searchCriteria !='Country'){
						MessageSvc.displayInfoMessage("Error while retrieving data, please try again.");
					}
					else{
						if(searchCriteria=='Country'){
							self.countryData = response.data;
							$rootScope.$broadcast('countryDataObject',data);

						}else if(searchCriteria=='Network'){

							self.networkData = self.Data;
							$rootScope.$broadcast('networkDataObject',data);
						}

						else if(searchCriteria=='ProductDetails'){

							self.prodDetData = self.Data;
							$rootScope.$broadcast('prodDetDataObject',data);
						}
						else if(searchCriteria=='Product')
						{

							self.prodData = self.Data;
							$rootScope.$broadcast('prodDataObject',data);
						}
					}
					
					});
		}   





	}
	return new AllEspSearchSvc();
}])

.factory('myService', function() {
	var savedData = {}
	function set(data) {
		savedData = data;
	}
	function get() {
		return savedData;
	}

	return {
		set: set,
		get: get
	}

})


.factory('ReportSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                       function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {
	function ReportSvc() {
		//var self = this;   			

		this.updateReportGenerationDetails=function(reportTpe,reportInpt){

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetReportDetailUrl = webSRCPath + cfg.updateReportDetail;
			});

			var param=new FormData();
			var reportType=null;
			var reportInput=null;
			if(reportTpe === "ESP Name"){
				reportType="DtlByESPName";
				reportInput={"espName" : reportInpt};
			}
			else if(reportTpe === "ESP Product"){
				reportType="DtlByEspProductId";
				reportInput={"espProductId" : reportInpt};
			}
			else if(reportTpe === "ATT Product"){
				reportType="DtlByAttProductId";
				reportInput={"attProductId" : reportInpt};
			}
			var url=self.GetReportDetailUrl;            			
			$rootScope.$broadcast('BusyStart');

			param.append('ReportTyp',reportType);
			param.append('ReportInput',	JSON.stringify(reportInput));
			param.append('userId',$cookieStore.get("attuid"));

			$http.post(url, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			})
			.then( function(response) 
					{

				$rootScope.$broadcast('BusyEnd');
				var data=response.data;
				self.reportData = data;
				//console.log("length of the object: "+data.length);
				if(self.reportData.value === "SUCCESS")
				{
					MessageSvc.displayInfoMessage("Thank you for submitting a request , you will receive an email with the report ASAP");
					$('#info-msg').modal('show');
					$("#info-msg").find("#okBtn").on("click", function () {
						// window.location.reload();
					});
				}
					});
		};
	}
	return new ReportSvc();
}])




.factory('Excel',function($window){
	var uri='data:application/vnd.ms-excel;base64,',
	template='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
	base64=function(s){return $window.btoa(unescape(encodeURIComponent(s)));},
	format=function(s,c){return s.replace(/{(\w+)}/g,function(m,p){return c[p];})};

	return {
		tableToExcel:function(tableId,worksheetName){
			var table=$(tableId),
			ctx={worksheet:worksheetName,table:table.html()},
			href=uri+base64(format(template,ctx));
			return href;
		}
	};
})            



.factory('TransactionSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                            function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function TransactionSvc()
	{

		var tempObj = this;
		this.transactionDataObj = {};
		this.transactionData = {};

		// searchByTxnDetails service - searching Transaction details based on APIName, Date, StartTime, EndTime and FromApplication.
		this.searchByTransactionDetails = function (APIName, Date, StartTime, EndTime, FromApplication, ATTUID) {
			var param=new FormData();
			param.append('api_name',APIName);
			param.append('date',Date);
			param.append('start_time',StartTime);
			param.append('end_time',EndTime);
			param.append('from_app',FromApplication);
			param.append('attuId',ATTUID);

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetTxnDetailsUrl = webSRCPath + cfg.searchByTxnDetails;
			});
			var searchTxnDetailsUrl=self.GetTxnDetailsUrl;

			$http.post(searchTxnDetailsUrl, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			}).success(function (response) {

				var allDetails=response;
				tempObj.transactionData = allDetails;

				$rootScope.$broadcast('transactionallDetailsObject',allDetails);
			});
		};

		// searchByTransactionID service - searching Transaction details based on TransactionID only
		this.searchByTransactionID = function (TransactionID, ATTUID) {   	
			var param=new FormData();


			param.append('transactionId',TransactionID);
			param.append('attuId',ATTUID);

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetSearchTransactionUrl = webSRCPath + cfg.searchByTransaction;
			});
			var searchByTransactionUrl=self.GetSearchTransactionUrl;

			$http.post(searchByTransactionUrl, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			}).success(function (response) {

				var dataAll=response;
				tempObj.transactionDataObj = dataAll;
				$rootScope.$broadcast('transactionDataObject',dataAll);
			});
		};
	}

	return new TransactionSvc();
}])

.factory('XMLGenSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                       function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	//service to make XML string to collapsible form
	function XMLGenSvc()
	{
		this.LoadXML = function (ParentElementID,URL) 
		{
			var xmlHolderElement = this.GetParentElement(ParentElementID);
			if (xmlHolderElement==null) { return false; }
			this.ToggleElementVisibility(xmlHolderElement);
			return this.RequestURL(URL,$rootScope.URLReceiveCallback,ParentElementID);
		}
		this.LoadXMLDom = function (ParentElementID,xmlDoc) 
		{
			if (xmlDoc) {
				var xmlHolderElement = this.GetParentElement(ParentElementID);
				if (xmlHolderElement==null) { return false; }
				while (xmlHolderElement.childNodes.length) { xmlHolderElement.removeChild(xmlHolderElement.childNodes.item(xmlHolderElement.childNodes.length-1));	}
				var Result = this.ShowXML(xmlHolderElement,xmlDoc.documentElement,0);

				var ReferenceElement = document.createElement('div');
				var Link = document.createElement('a');		
				Link.setAttribute('href','http://www.levmuchnik.net/Content/ProgrammingTips/WEB/XMLDisplay/DisplayXMLFileWithJavascript.html');

				xmlHolderElement.appendChild(Link);
				return Result;
			}
			else { return false; }
		}
		////////////////////////////////////////////////////////////
		// HELPER FUNCTIONS - SHOULD NOT BE DIRECTLY CALLED BY USERS
		////////////////////////////////////////////////////////////
		this.GetParentElement = function (ParentElementID)
		{
			if (typeof(ParentElementID)=='string') {	return document.getElementById(ParentElementID);	}
			else if (typeof(ParentElementID)=='object') { return ParentElementID;} 
			else { return null; }
		}
		this.URLReceiveCallback = function (httpRequest,xmlHolderElement)
		{
			try {
				if (httpRequest.readyState == 4) {
					if (httpRequest.status == 200) {
						var xmlDoc = httpRequest.responseXML;
						if (xmlHolderElement && xmlHolderElement!=null) {
							xmlHolderElement.innerHTML = '';
							return this.LoadXMLDom(xmlHolderElement,xmlDoc);
						}
					} else {
						return false;
					}
				}
			}
			catch( e ) {
				return false;
			}	
		}
		this.RequestURL = function (url,callback,ExtraData) { // based on: http://developer.mozilla.org/en/docs/AJAX:Getting_Started
			var httpRequest;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				httpRequest = new XMLHttpRequest();
				if (httpRequest.overrideMimeType) { httpRequest.overrideMimeType('text/xml'); }
			} 
			else if (window.ActiveXObject) { // IE
				try { httpRequest = new ActiveXObject("Msxml2.XMLHTTP");   } 
				catch (e) {
					try { httpRequest = new ActiveXObject("Microsoft.XMLHTTP"); } 
					catch (e) {}
				}
			}
			if (!httpRequest) { return false;   }
			httpRequest.onreadystatechange = function() { callback(httpRequest,ExtraData); };
			httpRequest.open('GET', url, true);
			httpRequest.send('');
			return true;
		}
		this.CreateXMLDOM = function (XMLStr) 
		{
			if (window.ActiveXObject)
			{
				xmlDoc=new ActiveXObject("Microsoft.XMLDOM"); 
				xmlDoc.loadXML(XMLStr);	
				return xmlDoc;
			}
			else if (document.implementation && document.implementation.createDocument)	  {
				var parser=new DOMParser();
				return parser.parseFromString(XMLStr,"text/xml");
			}
			else {
				return null;
			}
		}		

		var IDCounter = 1;
		var NestingIndent = 15;

		this.ShowXML = function (xmlHolderElement,RootNode,indent)
		{
			if (RootNode==null || xmlHolderElement==null) { return false; }
			var Result  = true;
			var TagEmptyElement = document.createElement('div');
			TagEmptyElement.className = 'Element';
			TagEmptyElement.style.position = 'relative';
			TagEmptyElement.style.left = NestingIndent+'px';
			var TagElement = document.createElement('div');

			if (RootNode.childNodes.length==0) { 
				var ClickableElement = AddTextNode(TagEmptyElement,'','Clickable') ;
				ClickableElement.id = 'div_empty_' + IDCounter;	  
				this.AddTextNode(TagEmptyElement,'<','Utility') ;
				this.AddTextNode(TagEmptyElement,RootNode.nodeName ,'NodeName') 
				for (var i = 0; RootNode.attributes && i < RootNode.attributes.length; ++i) {
					CurrentAttribute  = RootNode.attributes.item(i);
					this.AddTextNode(TagEmptyElement,' ' + CurrentAttribute.nodeName ,'AttributeName') ;
					this.AddTextNode(TagEmptyElement,'=','Utility') ;
					this.AddTextNode(TagEmptyElement,'"' + CurrentAttribute.nodeValue + '"','AttributeValue') ;
				}
				this.AddTextNode(TagEmptyElement,' />') ;
				xmlHolderElement.appendChild(TagEmptyElement);	
				//SetVisibility(TagEmptyElement,true);    
			}
			else { // mo child nodes

				var ClickableElement = this.AddTextNode(TagEmptyElement,'+','Clickable') ;
				var self = this;
				ClickableElement.id = 'div_empty_' + IDCounter;	
				ClickableElement.onclick  = function() {self.ToggleElementVisibility(this); }
				this.AddTextNode(TagEmptyElement,'<','Utility') ;
				this.AddTextNode(TagEmptyElement,RootNode.nodeName ,'NodeName') 
				for (var i = 0; RootNode.attributes && i < RootNode.attributes.length; ++i) {
					var CurrentAttribute  = RootNode.attributes.item(i);
					this.AddTextNode(TagEmptyElement,' ' + CurrentAttribute.nodeName ,'AttributeName') ;
					this.AddTextNode(TagEmptyElement,'=','Utility') ;
					this.AddTextNode(TagEmptyElement,'"' + CurrentAttribute.nodeValue + '"','AttributeValue') ;
				}

				this.AddTextNode(TagEmptyElement,'>  </','Utility') ;
				this.AddTextNode(TagEmptyElement,RootNode.nodeName,'NodeName') ;
				this.AddTextNode(TagEmptyElement,'>','Utility') ;
				xmlHolderElement.appendChild(TagEmptyElement);	
				this.SetVisibility(TagEmptyElement,false);
				//----------------------------------------------

				TagElement = document.createElement('div');
				TagElement.className = 'Element';
				TagElement.style.position = 'relative';
				TagElement.style.left = NestingIndent+'px';
				ClickableElement = this.AddTextNode(TagElement,'-','Clickable') ;
				ClickableElement.id = 'div_content_' + IDCounter;
				++IDCounter;
				var that = this;
				ClickableElement.onclick  = function() {that.ToggleElementVisibility(ClickableElement); }

				this.AddTextNode(TagElement,'<','Utility') ;
				this.AddTextNode(TagElement,RootNode.nodeName ,'NodeName') ;

				for (var i = 0; RootNode.attributes && i < RootNode.attributes.length; ++i) {
					CurrentAttribute  = RootNode.attributes.item(i);
					this.AddTextNode(TagElement,' ' + CurrentAttribute.nodeName ,'AttributeName') ;
					this.AddTextNode(TagElement,'=','Utility') ;
					this.AddTextNode(TagElement,'"' + CurrentAttribute.nodeValue + '"','AttributeValue') ;
				}
				this.AddTextNode(TagElement,'>','Utility') ;
				TagElement.appendChild(document.createElement('br'));
				var NodeContent = null;
				for (var i = 0; RootNode.childNodes && i < RootNode.childNodes.length; ++i) {
					if (RootNode.childNodes.item(i).nodeName != '#text') {
						Result &= this.ShowXML(TagElement,RootNode.childNodes.item(i),indent+1);
					}
					else {
						NodeContent =RootNode.childNodes.item(i).nodeValue;
					}					
				}			
				if (RootNode.nodeValue) {
					NodeContent = RootNode.nodeValue;
				}
				if (NodeContent) {	
					var ContentElement = document.createElement('div');
					ContentElement.style.position = 'relative';
					ContentElement.style.left = NestingIndent+'px';			
					this.AddTextNode(ContentElement,NodeContent ,'NodeValue') ;
					TagElement.appendChild(ContentElement);
				}			
				this.AddTextNode(TagElement,'  </','Utility') ;
				this.AddTextNode(TagElement,RootNode.nodeName,'NodeName') ;
				this.AddTextNode(TagElement,'>','Utility') ;
				xmlHolderElement.appendChild(TagElement);	
			}
			if (indent === 0) 
			{ 
				this.ToggleElementVisibility(TagElement.childNodes.item(0)); 
			} //- uncomment to collapse the external element
			return Result;
		}
		this.AddTextNode = function (ParentNode,Text,Class) 
		{
			var NewNode = document.createElement('span');
			if (Class) {  NewNode.className  = Class;}
			if (Text) { NewNode.appendChild(document.createTextNode(Text)); }
			if (ParentNode) { ParentNode.appendChild(NewNode); }
			return NewNode;		
		}
		this.CompatibleGetElementByID = function (id)
		{
			if (!id) { return null; }
			if (document.getElementById) { // DOM3 = IE5, NS6
				return document.getElementById(id);
			}
			else {
				if (document.layers) { // Netscape 4
					return document.id;
				}
				else { // IE 4
					return document.all.id;
				}
			}
		}
		this.SetVisibility = function (HTMLElement,Visible)
		{
			if (!HTMLElement) { return; }
			var VisibilityStr  = (Visible) ? 'block' : 'none';
			if (document.getElementById) { // DOM3 = IE5, NS6
				HTMLElement.style.display =VisibilityStr; 
			}
			else {
				if (document.layers) { // Netscape 4
					HTMLElement.display = VisibilityStr; 
				}
				else { // IE 4
					HTMLElement.id.style.display = VisibilityStr; 
				}
			}
		}
		this.ToggleElementVisibility = function (Element)
		{

			var ElementType;
			var ElementID;
			if (!Element || !Element.id) { 
				return; }
			try {
				ElementType = Element.id.slice(0,Element.id.lastIndexOf('_')+1);
				ElementID = parseInt(Element.id.slice(Element.id.lastIndexOf('_')+1));
			}
			catch(e) { 
				return ; }
			var ElementToHide = null;
			var ElementToShow= null;
			if (ElementType=='div_content_') {
				ElementToHide = 'div_content_' + ElementID;
				ElementToShow = 'div_empty_' + ElementID;
			}
			else if (ElementType=='div_empty_') {
				ElementToShow= 'div_content_' + ElementID;
				ElementToHide  = 'div_empty_' + ElementID;
			}
			ElementToHide = this.CompatibleGetElementByID(ElementToHide);
			ElementToShow = this.CompatibleGetElementByID(ElementToShow);
			if (ElementToHide) { ElementToHide = ElementToHide.parentNode;}
			if (ElementToShow) { ElementToShow = ElementToShow.parentNode;}
			this.SetVisibility(ElementToHide,false);
			this.SetVisibility(ElementToShow,true);
		}
	}
	return new XMLGenSvc();

}])


.factory('AddSupportSvc', [ '$http','$rootScope', '$log', '$cookieStore', 'ConfigSvc', '$sce', '$routeParams','MessageSvc',
                            function ($http,$rootScope,  $log, $cookieStore, ConfigSvc, $sce, $routeParams,MessageSvc) {
	function AddSupportSvc() {
		var self = this;
		this.addSupportData = {};

		this.addSupportDetails=function(CATEGORY,QUESTION,ANSWER,DESCRIPTION,CATEGORYRef,TITLE,LINK,DESCRIPTIONRef){


			console.log("service called for add support");
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetaddSupportUrl = webSRCPath + cfg.addSupportDetails;
			});

			var url=self.GetaddSupportUrl;
			console.log("url to connect to service: "+url);

			/*var addData =	{
	          			"attuid": "mm112f",
	          			"faq": {
	          			"category": "cat",
	          			"question": "quest",
	          			"answer": "answer1",
	          			"description": "link"
	          			}
	          			};*/
			//console.log("in refrence adddata");
			console.log("value of category: "+CATEGORY+" and question :"+QUESTION);
			if(!(CATEGORY == null && QUESTION == null && ANSWER == null) && (CATEGORYRef == null && TITLE == null && LINK == null))
			{
				console.log("inside if in service");
				var addData={
						"attuid": $cookieStore.get("attuid"),
						/*	"attuid": "ag550k",*/
						"faq": {
							"category": CATEGORY,
							"question": QUESTION,
							"answer": ANSWER,
							"description": DESCRIPTION
						}

				};
			}
			else if(!(CATEGORYRef == null && TITLE == null && LINK == null) && (CATEGORY == null && QUESTION == null && ANSWER == null)){
				console.log("inside else if in service");
				var addData={
						"attuid": $cookieStore.get("attuid"),
						/*"attuid": "ag550k",*/
						"references": {
							"category": CATEGORYRef,
							"title": TITLE,
							"link": LINK,
							"description": DESCRIPTIONRef
						}
				};	
			}

			$rootScope.$broadcast('BusyStart');

			console.log("addData"+JSON.stringify(addData))
			var final=JSON.stringify(addData);
			var getAllAdminLinks = {
					method : 'POST',
					url : url,
					data : final,
			};

			$http(getAllAdminLinks).success( 
					function(data) {
						console.log("+++++++data+++++++++"+JSON.stringify(data));
						console.log("entered");
						console.log("data---"+data.value);
						if(data.value==='SUCCESS'){
							MessageSvc.displayInfoMessage("Data Added Successfully");
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {
								console.log("++++++++++INSIDE OK BTN");
								// $('#info-msg').modal('hide');
								window.location.reload();
							});
								} else{
									if(data.value==='DUPLICATE'){										
										MessageSvc.displayErrorMessage('Error while adding data. Please try again.');
									} else {										
										MessageSvc.displayErrorMessage('Error while adding data.');
						}
									 $('#error-msg').modal('show');
				                        $("#error-msg").find("#okBtn").on("click", function () {
								//$('#info-msg').modal('hide');
								// window.close();
				                        	//window.location.reload();
							});
						}
					})
					$rootScope.$broadcast('BusyEnd');
		}

	}

	return new AddSupportSvc();
}])





.factory('GetSupportDetailsSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', '$sce', '$routeParams',
                                  function ($rootScope, $http, $log, $cookieStore, ConfigSvc, $sce, $routeParams) {
	console.log("Inside DropDown Service");
	function GetSupportDetailsSvc() {
		var self = this;
		this.supportDetailsData = {};               	
		this.getSupportDetails=function(value,attuid){
			console.log("Service called for getSupportDetails");
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				$log.info("webSRCPath"+webSRCPath);

				//self.GetSupportDetailsURL = webSRCPath + "pedespws/restservice/getSupportDetails/";
				self.GetSupportDetailsURL = webSRCPath +cfg.fetchSupportDetails;
				var param=new FormData();
				var url=self.GetSupportDetailsURL;
				console.log("url to connect get support detail: "+url);

				param.append('attuId',$cookieStore.get("attuid"));
				param.append('type',value);

				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					var data=response.data;
					self.supportDetailsData = data;
					//console.log("value of supportDetails data in services: "+JSON.stringify(self.supportDetailsData));
					$rootScope.$broadcast('supportDetailsDataObject',data);        				

						});
			});
		};
	}
	return new GetSupportDetailsSvc();
}])

.factory('DeleteSupportSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function DeleteSupportSvc()
	{

		var self = this;

		this.deleteSupportRecord = function (attuId,supportId) {

			console.log('attuid : '+$cookieStore.get("attuid")+' support Id : '+supportId);
			console.log("In Services.js - deleteSupportRecord");

			var param=new FormData();
			param.append('supptid',supportId);
			param.append('attuid',$cookieStore.get("attuid"));

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				//self.deleteSupportUrl = webSRCPath + "pedespws/restservice/deleteSupportDetails/";
				self.deleteSupportUrl = webSRCPath + cfg.deleteSupportDetails;
				console.log('value of delete url from cfg :'+self.deleteSupportUrl);
			});
			var deleteSupportRecordUrl=self.deleteSupportUrl;
			console.log('value of delete URL '+deleteSupportRecordUrl);

			$http.post(deleteSupportRecordUrl, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			}).success(function (response) {
				console.log("In Services.js - delete support record SUCCESS");

				var allDetails=response;

				console.log("Delete response from webservice "+JSON.stringify(allDetails));
				if(response.value==='SUCCESS'){
					MessageSvc.displayInfoMessage("Data Deleted Successfully");
					$('#update-cnfrm').modal('hide');
					$('#info-msg').modal('show');
					$("#info-msg").find("#okBtn").on("click", function () {
						//console.log("++++++++++INSIDE OK BTN");
						window.location.reload();
					});
				}else{
					MessageSvc.displayErrorMessage('Error while adding deleting Data');
					$('#update-cnfrm').modal('hide');
					$('#update-detail').modal('hide');
					$('#info-msg').modal('show');
					$("#info-msg").find("#okBtn").on("click", function () {
						window.location.reload();
					});
				}

			});
		};
	}

	return new DeleteSupportSvc();
}])


.factory('UpdateSupportSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function UpdateSupportSvc()
	{

		var self = this;

		this.updateSupportRecord = function (recordData,type,attuId) {

			console.log('Data to be updated '+ JSON.stringify(recordData));
			console.log('Data type to be updated 1 '+ recordData.id);
			var updateData;
			if(type == 'FAQ'){
				updateData={
						"attuid": $cookieStore.get("attuid"),
						"faq": {
							"category": recordData.category,
							"question": recordData.question,
							"answer": recordData.answer,
							"description": recordData.description,
							"id" : recordData.id
						}
				}
			}else if(type == 'REF'){
				updateData={
						"attuid": $cookieStore.get("attuid"),
						"references": {
							"title": recordData.title,
							"link": recordData.link,
							"category": recordData.category,
							"description": recordData.description,
							"id" : recordData.id
						}
				}
			}

			console.log('fianl data to be sent to service for update : '+JSON.stringify(updateData));

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.updateSupportUrl = webSRCPath + cfg.updateSupportDetails;
				//self.updateSupportUrl = webSRCPath + "pedespws/restservice/updateSupportDetails/";
				console.log('value of delete url from cfg :'+self.updateSupportUrl);
			});

			var updateSupportRecordUrl=self.updateSupportUrl;
			var dataStr=JSON.stringify(updateData);
			$rootScope.$broadcast('BusyStart');

			var getAllAdminLinks = {
					method : 'POST',
					url : updateSupportRecordUrl,
					data : dataStr,
			};

			$http(getAllAdminLinks).success( 
					function(data) {
						console.log("+++++++data+++++++++"+JSON.stringify(data));
						console.log("entered");
						console.log("data---"+data.value);
						if(data.value==='SUCCESS'){
							MessageSvc.displayInfoMessage("Data Updated Successfully");
							$('#update-cnfrm').modal('hide');
							$('#update-detail').modal('hide');
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {			                 
								window.location.reload();

							});
						}
						else{
							MessageSvc.displayErrorMessage('Error while adding updating Data');
							$('#update-cnfrm').modal('hide');
							$('#update-detail').modal('hide');
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {
								window.location.reload();
							});
						}
					})

		};
	}

	return new UpdateSupportSvc();
}])
.factory('UpdateConfigSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                             function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function UpdateConfigSvc(){


		var self = this;

		this.updateConfigRecord = function (recordData,attuId) {		
			console.log('Data to be updated '+ JSON.stringify(recordData));			
			var updateData;			
			updateData={
					"attuid": $cookieStore.get("attuid"),					 
					"key": recordData.key,
					"value": recordData.value,	
					"description": recordData.description
			};


			console.log('fianl data to be sent to service for update : '+JSON.stringify(updateData));

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.updateSupportUrl = webSRCPath + cfg.updateConfigProperties;
				//self.updateSupportUrl = webSRCPath + "pedespws/restservice/updateSupportDetails/";
				console.log('value of delete url from cfg :'+self.updateSupportUrl);
			});

			var updateSupportRecordUrl=self.updateSupportUrl;			
			var dataStr=JSON.stringify(updateData);
			$rootScope.$broadcast('BusyStart');

			var getAllAdminLinks = {
					method : 'POST',
					url : updateSupportRecordUrl,
					data : dataStr,
			};

			$http(getAllAdminLinks).success( 
					function(data) {
						console.log("+++++++data+++++++++"+JSON.stringify(data));
						console.log("entered");
						console.log("data---"+data.value);
						if(data.value==='SUCCESS'){
							MessageSvc.displayInfoMessage("Data Updated Successfully");
							$('#update-cnfrm').modal('hide');
							$('#update-detail').modal('hide');
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {			                 
								window.location.reload();

							});
						}
						else{
							MessageSvc.displayErrorMessage('Error while adding updating Data');
							$('#update-cnfrm').modal('hide');
							$('#update-detail').modal('hide');
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {
								window.location.reload();
							});
						}
					});

		};

	}

	return new UpdateConfigSvc();
}])


.factory('DeleteConfigSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                             function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function DeleteConfigSvc()
	{

		var self = this;

		this.deleteConfigRecord = function (attuId,configKey) {

			console.log('attuid : '+$cookieStore.get("attuid")+' config Key: '+configKey);
			console.log("In Services.js - deleteConfigRecord");

			var param=new FormData();
			param.append('key',configKey);
			/*param.append('attuid',$cookieStore.get("attuid"));*/

			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				//self.deleteSupportUrl = webSRCPath + "pedespws/restservice/deleteSupportDetails/";
				self.deleteSupportUrl = webSRCPath + cfg.deleteConfigProperties;
				console.log('value of delete url from cfg :'+self.deleteSupportUrl);
			});
			var deleteSupportRecordUrl=self.deleteSupportUrl;
			console.log('value of delete URL '+deleteSupportRecordUrl);

			$http.post(deleteSupportRecordUrl, param, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			}).success(function (response) {
				console.log("In Services.js - delete support record SUCCESS");

				var allDetails=response;

				console.log("Delete response from webservice "+JSON.stringify(allDetails));
				if(response.value==='SUCCESS'){
					MessageSvc.displayInfoMessage("Data Deleted Successfully");
					$('#update-cnfrm').modal('hide');
					$('#info-msg').modal('show');
					$("#info-msg").find("#okBtn").on("click", function () {
						//console.log("++++++++++INSIDE OK BTN");
						window.location.reload();
					});
				}else{
					MessageSvc.displayErrorMessage('Error while adding deleting Data');
					$('#update-cnfrm').modal('hide');
					$('#update-detail').modal('hide');
					$('#info-msg').modal('show');
					$("#info-msg").find("#okBtn").on("click", function () {
						window.location.reload();
					});
				}

			});
		};
	}

	return new DeleteConfigSvc();
}])


.factory('AddConfigSvc', [ '$http','$rootScope', '$log', '$cookieStore', 'ConfigSvc', '$sce', '$routeParams','MessageSvc',
                           function ($http,$rootScope,  $log, $cookieStore, ConfigSvc, $sce, $routeParams,MessageSvc) {
	function AddConfigSvc() {
		var self = this;
		this.addSupportData = {};

		this.addConfigDetails=function(key,value,description){


			console.log("service called for add support");
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.GetaddSupportUrl = webSRCPath + cfg.addConfigProperties;
			});

			var url=self.GetaddSupportUrl;
			console.log("url to connect to service: "+url);
			var addData={
					"attuid": $cookieStore.get("attuid"),					 
					"key": key,
					"value": value,
					"description": description
			};
			$rootScope.$broadcast('BusyStart');

			console.log("addData"+JSON.stringify(addData));
			var final=JSON.stringify(addData);
			var getAllAdminLinks = {
					method : 'POST',
					url : url,
					data : final,
			};

			$http(getAllAdminLinks).success( 
					function(data) {
						console.log("+++++++data+++++++++"+JSON.stringify(data));
						console.log("entered");
						console.log("data---"+data.value);
						if(data.value==='SUCCESS'){
							MessageSvc.displayInfoMessage("Data Added Successfully");
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {
								console.log("++++++++++INSIDE OK BTN");
								// $('#info-msg').modal('hide');
								window.location.reload();
							});
						}
						else{
							MessageSvc.displayErrorMessage('Error while adding data');
							$('#info-msg').modal('show');
							$("#info-msg").find("#okBtn").on("click", function () {
								//$('#info-msg').modal('hide');
								// window.close();
								window.location.reload();
							});
						}
					});
			$rootScope.$broadcast('BusyEnd');
		};

	}

	return new AddConfigSvc();
}])


.factory('GetCatalogValidValSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function GetCatalogValidValSvc()
	{

		var self = this;

		this.getCatalogValues = function (dataType) {

			console.log('Data type to be fetched1 '+ dataType);
			var element='';
			var param=new FormData();
			param.append('key','DATA_TYPE');
			param.append('dataType',dataType);
			param.append('element',element);
			param.append('attuId',$cookieStore.get("attuid").toLowerCase());
			
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.getCatalogValuesUrl = webSRCPath + cfg.fetchCatalogValues; 
				//"http://localhost:8080/pedespws/restservice/getValidValues/"
				var url=self.getCatalogValuesUrl;
				
				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					//console.log('value of response recieved : '+JSON.stringify(response.data));
					var data=response.data;
					self.espCatalogValidVals = data;
					$rootScope.$broadcast('espCatalogDataObject',data);        				
					
						});
			});
			
		};
	}

	return new GetCatalogValidValSvc();
}])




.factory('uploadSvcMoW', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$routeParams',
      function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc,  $routeParams) {

			function uploadSvcMoW()
			{
				var self = this;
		
				this.uploadFileMoW = function(coverageName, bufferRadius, geoCodingThreshold, technologyType, fullRefresh, fileHandle)
				{   
        	    	console.log("Inside uploadSvcMoW service");
        	    	
        	    	console.log("Parameters in Service.js : ");
        	    	console.log("coverageName : "+coverageName);
        	    	console.log("bufferRadius : "+bufferRadius);
        	    	console.log("geoCodingThreshold : "+geoCodingThreshold);
        	    	console.log("technologyType : "+technologyType);
        	    	console.log("fullRefresh : "+fullRefresh);

					var fd = new FormData();
					fd.append('coverageName',coverageName);
					fd.append('bufferRadius',bufferRadius);
					fd.append('geoCodingThreshold',geoCodingThreshold);
					fd.append('technologyType',technologyType);
					fd.append('fullRefresh',fullRefresh);
					fd.append('userid',$cookieStore.get("attuid"));
					fd.append('request', fileHandle);
		
					ConfigSvc.getConfig(function (cfg) {
						var webSRCPath = ConfigSvc.getAbsPath();
						self.GetFileUploadUrl = cfg.ESPMowUploadSrvc;
					});
					
					$log.info("uploadFileMoW URL : "+self.GetFileUploadUrl);
					
					var fileUploadUrl=self.GetFileUploadUrl;
					$rootScope.$broadcast('BusyStart');
					$http.post(fileUploadUrl, fd, 
					{
						transformRequest: angular.identity,
						headers: {'Content-Type': undefined}
					 })
					 .then( function(response) 
					 {
							var data=response.data;
		        	    	console.log("uploadSvcMoW service Response Object : "+data);
		        	    	
							$rootScope.$broadcast('BusyEnd');
							if(data == null)
							{
								MessageSvc.displayErrorMessage ("Error uploading the file, please try again.");
								console.log("Error while uploading the file, Please try again. Contact Administrator if this issue persists.");
							}
							else
							{
								MessageSvc.displayInfoMessage ("File Uploaded Successfully, data is processed periodically and you would receive an email after the upload process is complete.");
								console.log("File Uploaded Successfully, Data is processed periodically and you would receive an email after the Upload process is complete.");
							}
					 });
        	    	console.log("Outside uploadSvcMoW service");
				}
			} 
	return new uploadSvcMoW();
}])


.factory('UpdtCatalogValidValSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function UpdtCatalogValidValSvc()
	{

		var self = this;

		this.updateCatalogValues = function (values) {

			console.log('Data type to be fetched1 '+ JSON.stringify(values));
			var element='';
			var param=new FormData();
			var validVal=values.editValues;
			for(var i=0;i<values.editValues.length;i++){
				if(values.editValues[i] == null || values.editValues[i] == '' || values.editValues[i] == undefined){
					
					//values.editValues.splice(i,1);
					validVal.splice(i,1);
					console.log('splicing1 '+JSON.stringify(validVal.splice(i,1)));
				}
			}
			var element=values.elementType+':'+validVal; //values.editValues.toString();
			console.log('element in service : '+element);
			param.append('key','DATA_TYPE');
			param.append('dataType',values.dataType);
			param.append('element',element);
			param.append('attuId',$cookieStore.get("attuid").toLowerCase());
			param.append('Id',values.id);
			
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.updateCatalogValuesUrl = webSRCPath + cfg.updateCatalogValues;
				//"http://localhost:8080/pedespws/restservice/updateValidVal/";
				
				var url=self.updateCatalogValuesUrl;
				
				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					//console.log('value of response recieved : '+JSON.stringify(response));
					var data=response.data;
					self.espCatalogValidVals = data;
					//$rootScope.$broadcast('espCatalogDataObject',data); 
					if(data.value==='SUCCESS'){
						MessageSvc.displayInfoMessage("Data Updated Successfully");
						$('#catalog-cnfrm').modal('hide');
						$('#catalog-values').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {			                 
							window.location.reload();

						});
					}
					else{
						MessageSvc.displayErrorMessage('Error while adding updating Data');
						$('#catalog-cnfrm').modal('hide');
						$('#catalog-values').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {
							window.location.reload();
						});
					}

						});
			});
			
		};
	}

	return new UpdtCatalogValidValSvc();
}])


.factory('DeleteCatalogValidValSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function DeleteCatalogValidValSvc()
	{

		var self = this;

		this.deleteCatalogValues = function (id) {

			console.log('id of Data type to be deleted '+ id);
			var param=new FormData();
			
			param.append('Id',id);
			
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.deleteCatalogValuesUrl = webSRCPath + cfg.deleteCatalogValues;
				//"http://localhost:8080/pedespws/restservice/deleteValidVal/";
				
				var url=self.deleteCatalogValuesUrl;
				
				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					//console.log('value of response recieved : '+JSON.stringify(response));
					var data=response.data;
					self.espCatalogValidVals = data;
					//$rootScope.$broadcast('espCatalogDataObject',data); 
					if(data.value==='SUCCESS'){
						MessageSvc.displayInfoMessage("Data Deleted Successfully");
						$('#catalog-cnfrm').modal('hide');
						$('#catalog-values').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {			                 
							window.location.reload();

						});
					}
					else{
						MessageSvc.displayErrorMessage('Error while adding deleting Data');
						$('#catalog-cnfrm').modal('hide');
						$('#catalog-values').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {
							window.location.reload();
						});
					}

						});
			});
			
		};
	}

	return new DeleteCatalogValidValSvc();
}])



.factory('AddCatalogDataSvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                              function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {

	function AddCatalogDataSvc()
	{

		var self = this;

		this.addCatalogData = function (data) {
			
			var param=new FormData();
			/*for(var i=0;i<values.editValues.length;i++){
				if(values.editValues[i] == null || values.editValues[i] == '' || values.editValues[i] == undefined){
					values.editValues.splice(i,1);
				}
			}*/
			var element=data.element+':'+data.values;
			console.log('element in service : '+element);
			param.append('key','DATA_TYPE');
			param.append('dataType',data.dataType);
			param.append('element',element);
			param.append('attuId',$cookieStore.get("attuid").toLowerCase());
			
			
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				self.addCatalogDataUrl = webSRCPath + cfg.addCatalogData;
				//"http://localhost:8080/pedespws/restservice/addValidVal/";
				
				var url=self.addCatalogDataUrl;
				
				$rootScope.$broadcast('BusyStart');

				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{

					$rootScope.$broadcast('BusyEnd');
					//console.log('value of response recieved : '+JSON.stringify(response));
					var data=response.data;
					self.espCatalogValidVals = data;
					//$rootScope.$broadcast('espCatalogDataObject',data); 
					if(data.value==='SUCCESS'){
						MessageSvc.displayInfoMessage("Data Added Successfully");
						$('#catalog-cnfrm').modal('hide');
						$('#add-catalog').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {			                 
							window.location.reload();

						});
					}
					else{
						MessageSvc.displayErrorMessage('Error while adding adding Data');
						$('#catalog-cnfrm').modal('hide');
						$('#add-catalog').modal('hide');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {
							window.location.reload();
						});
					}

						});
			});
			
		};
	}

	return new AddCatalogDataSvc();
}])
.factory('GetEspEntrySvc', ['$rootScope', '$http', '$log', '$cookieStore', 'ConfigSvc', 'MessageSvc', '$sce', '$routeParams',
                                   function ($rootScope, $http, $log, $cookieStore, ConfigSvc, MessageSvc, $sce, $routeParams) {
	
	function GetEspEntrySvc()
	{
		
		var self = this;
		this.entryDetailsData = {}; 
		
		
		this.getEntryDetails=function(ESPName,ESPFullName,COUNTRY){
			console.log("ESPName: "+ESPName+" ESPFullName: "+ESPFullName+" COUNTRY: "+COUNTRY)
			console.log("Service called for getEntryDetails");
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				$log.info("webSRCPath"+webSRCPath);

				//self.GetSupportDetailsURL = webSRCPath + "pedespws/restservice/getSupportDetails/";
				self.GetEntryDetailsURL = webSRCPath +cfg.fetchEspEntryData;
				
				var param=new FormData();
				var url=self.GetEntryDetailsURL;
				console.log("url to connect get entry detail: "+url);

				
				console.log("0");
				param.append('espName',ESPName);
				param.append('espFullName',ESPFullName);
				param.append('country',COUNTRY);
				param.append('attuId',"ag550k");
				console.log("1");
				$rootScope.$broadcast('BusyStart');
				console.log("2");
				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{
					console.log("3");
					$rootScope.$broadcast('BusyEnd');
					var data=response.data;
					console.log("data"+JSON.stringify(data));
					self.entryDetailsData = data;
					console.log("value of entryDetails data in services: "+JSON.stringify(self.entryDetailsData));
					$rootScope.$broadcast('entryDetailsDataObject',data);        				

						});
			});
			
		}
		
	}
	return new GetEspEntrySvc();
	
}])


.factory('AddEntrySvc', [ '$http','$rootScope', '$log', '$cookieStore', 'ConfigSvc', '$sce', '$routeParams','MessageSvc',
                            function ($http,$rootScope,  $log, $cookieStore, ConfigSvc, $sce, $routeParams,MessageSvc) {
	function AddEntrySvc()
	{
		console.log("in service")
		var self = this;
		this.addEntryDetailsData = {};
		
		this.addEntryDetails=function(value){
			console.log("Service called for addEntryDetails and value is: "+JSON.stringify(value));
			ConfigSvc.getConfig(function (cfg) {
				var webSRCPath = ConfigSvc.getAbsPath();
				$log.info("webSRCPath"+webSRCPath);

				self.addEntryDetailsURL = webSRCPath +cfg.addEspEntryData;
				
				var param=new FormData();
				var url=self.addEntryDetailsURL;
				console.log("url to connect get entry detail: "+url);

				var val = '[{"espName":"zdcf","espFullName":"df","hqCountryCode":"DE"},{"espName":"h","espFullName":"hg","hqCountryCode":"DE"}]';
				//[{"espName":"zdcf","espFullName":"df","hqCountryCode":"cb"},{"espName":"h","espFullName":"hg","hqCountryCode":"hgj"}]
				console.log("0");
				param.append('eSPEntryData',JSON.stringify(value));
				param.append('attuId',"ag550k");
				console.log("1");
				$rootScope.$broadcast('BusyStart');
				console.log("2");
				$http.post(url,param,{
					transformRequest: angular.identity,
					headers: {'Content-Type': undefined}
				})
				.then( function(response) 
						{
					console.log("3");
					$rootScope.$broadcast('BusyEnd');
					var data=response.data;
					
					if(data.value==='SUCCESS'){
						MessageSvc.displayInfoMessage("Data Added Successfully");
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {
							console.log("++++++++++INSIDE OK BTN");
							// $('#info-msg').modal('hide');
							window.location.reload();
						});
					}
					else{
						MessageSvc.displayErrorMessage('Error while adding data');
						$('#info-msg').modal('show');
						$("#info-msg").find("#okBtn").on("click", function () {
							//$('#info-msg').modal('hide');
							// window.close();
							window.location.reload();
						});
					}
					
					console.log("data"+data);
					//self.addEntryDetailsData = data;
					//console.log("value of entryDetails data in services: "+JSON.stringify(self.addEntryDetailsData));
					//$rootScope.$broadcast('addEntryDetailsDataObject',data);        				
						});
			});
		}
		
		
	}
	return new AddEntrySvc();

}]);


