/**
 * 
 */

$('.dropdown-menu').find('input').click(function (e) {
    e.stopPropagation();
});